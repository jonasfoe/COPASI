#include "ModuleImpl.h"
#include "MethodTable.h"
#include <string>

using namespace std;
using namespace SystemsBiologyWorkbench;


//#ifndef WIN32
//template<class T> void MethodTable<T>:: addMethod(Method method, std::string signature, bool synchronized /*= false*/, std::string help /*= ""*/)
//{
//	moduleImpl.setHandler(serviceName, new TemplateHandler(service, 
//		method), signature, synchronized, help);
//}
//#endif


