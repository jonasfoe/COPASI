#include "BrokerSessionKey.h"

using namespace SystemsBiologyWorkbench::Broker;

std::string BrokerSessionKey::sMyKey;
