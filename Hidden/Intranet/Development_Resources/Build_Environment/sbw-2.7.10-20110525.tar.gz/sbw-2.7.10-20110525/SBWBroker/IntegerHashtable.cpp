#include "IntegerHashtable.h"
#include "Instance.h"

using namespace SystemsBiologyWorkbench::Broker;

IntegerHashtable<Instance *> oInstanceTable;
