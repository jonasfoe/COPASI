######################################################################
# Copyright (C) 2001-2003 Peter J Jones (pjones@pmade.org)
# All Rights Reserved
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 3. Neither the name of the Author nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
# OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
# USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
######################################################################

use strict;
my $wchar = 80;
my $red = '';
my $green = '';
my $reset = '';

eval {
    require Term::ReadKey;
    import Term::ReadKey;
    ($wchar, undef, undef, undef) = GetTerminalSize();  
};

eval {
    require Term::ANSIColor;
    import Term::ANSIColor;
    $red = color("red");
    $green = color("green");
    $reset = color("reset");
};

my ($pass_count, $fail_count) = (0,0);
my $test_name = '';
my $dot_width = $wchar - 10;
my $id_pool = "aaaa";
my @short_names = qw(
    a b c d e f g h i j k l m n o p q r s t u v w x y z
    A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
    0 1 2 3 4 5 6 7 8 9 ? ! . = % ^ 
);
my $short_name_ptr = 0;

$|++;
print "| Test: $0\n";

sub test_start {
    my $name = shift;
    $test_name = $name;

    if (length($name) >= $dot_width) {
	$name = substr($name, 0, $dot_width - 4);
    }

    print "$name ", '.' x ($dot_width - length($name)), " ";
}

sub test_passed {
    ++$pass_count;
    print "${green}okay$reset\n";
}

sub test_failed {
    ++$fail_count;
    print "${red}fail$reset\n";
    print "($test_name)\n";
    exit 1;
}

sub get_id { 
    return $id_pool++;
}

sub get_short_name {
    if ($short_name_ptr >= @short_names) {
	die "$0: ran out of short names\n";
    }
    
    return $short_names[$short_name_ptr++];
}

sub reset_id_pool {
    $id_pool = "aaaa";
    $short_name_ptr = 0;
}

sub get_sandbox {
    return "sandbox";
}

sub get_xmlfile {
    return "options.xml";
}

sub run_cloxx {
    my $xmlfile = get_xmlfile();
    system("../../../../src/cmdline/clo++ -o c++ $xmlfile > /dev/null 2>&1");
}

sub all_tests_passed { return !$fail_count }

END {
    print '=-' x ($dot_width/2), "\n";
    print " Test: $0\n";
    print " Pass: $pass_count\n";
    print " Fail: $fail_count\n";
    print "Total: ", $pass_count + $fail_count, "\n";
    print '=-' x ($dot_width/2), "\n";
    if ($fail_count) {exit 1;}
}
