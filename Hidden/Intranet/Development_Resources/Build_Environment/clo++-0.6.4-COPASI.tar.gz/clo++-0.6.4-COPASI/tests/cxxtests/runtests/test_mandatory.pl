#! /usr/bin/perl -w
######################################################################
# Copyright (C) 2002-2003 Peter J Jones (pjones@pmade.org)
# All Rights Reserved
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 3. Neither the name of the Author nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
# OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
# USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
################################################################################
#
# test_mandatory.pl (Test mandatory stuff like options, groups and commands)
# Peter J Jones (pjones@pmade.org)
#
################################################################################
#
# Includes
#
################################################################################
use strict;
use Cwd qw(chdir cwd);
require "../utility/test_harness.pl";
################################################################################
#
# Constants
#
################################################################################
use constant DATE		=> 'Tue Apr  9 20:17:23 2002';
use constant ID			=> '$Id: test_mandatory.pl,v 1.2 2003/01/12 22:14:09 pjones Exp $';
################################################################################
#
# Global Variables
#
################################################################################
my $sandbox = get_sandbox();
my $xmlfile = get_xmlfile();
my $cxxfile = "main.cxx";
my $exefile = "test";

my @option_types = qw(flag bool enum int double string);
my $blank_command = '';
my $short_command = '';
my $long_command  = '';

$ENV{CXX} ||= "c++";
$ENV{CXXFLAGS} ||= '';
################################################################################
#
# Code Start
#
################################################################################
unless (chdir $sandbox) {
    print STDERR "$0: can't chdir into $sandbox: $!\n";
    exit 1;
}

open(CXX, ">$cxxfile") || die $!;
print CXX <<EOT;
#include "clo.h"
int main (int argc, char *argv[]) {
    try { clo::parser parser; parser.parse(argc, argv); }
    catch ( ... ) { return 1; }
    return 0;
}
EOT
close CXX;

test_options();
test_options_in_group();
test_options_in_command();
test_options_in_group_in_command();
test_command();

################################################################################
sub test_options {
    foreach my $type (@option_types) {
	reset_test();
	print XML <<EOT;
<cloxx>
    <options>
EOT
	gen_mandatory_option($type);
	print XML <<EOT;
    </options>
</cloxx>
EOT
	close XML;
	runtest("option($type)");
    }
}
################################################################################
sub test_options_in_group {
    foreach my $type (@option_types) {
	reset_test();
	my $group_id = get_id();
	my $opid = get_id();
	my $opshort = get_short_name();

	print XML <<EOT;
<cloxx>
    <group id="$group_id" type="xor">
	<option id="$opid" type="flag">
	    <name>$opid</name>
	    <name>$opshort</name>
	</option>
EOT
	gen_mandatory_option($type);
	
	print XML <<EOT;
    </group>
</cloxx>
EOT
	runtest("option($type) in group(xor)");
    }
}
################################################################################
sub test_options_in_command {
    foreach my $type (@option_types) {
	reset_test();
	my $cmdid = get_id();

	print XML <<EOT;
<cloxx>
    <command id="$cmdid">
	<name>$cmdid</name>
EOT

	gen_mandatory_option($type);

	print XML <<EOT;
    </command>
</cloxx>
EOT

	$short_command = "$cmdid $short_command";
	$long_command  = "$cmdid $long_command";
	$blank_command = "$cmdid";
	runtest("option($type) in command");
    }
}
################################################################################
sub test_options_in_group_in_command {
    foreach my $type (@option_types) {
	reset_test();
	my $cmdid = get_id();
	my $grpid = get_id();
	my $opid  = get_id();
	my $opshort = get_short_name();

	print XML <<EOT;
<cloxx>
    <command id="$cmdid">
	<name>$cmdid</name>
	<group id="$grpid" type="xor">
	    <option id="$opid" type="flag">
		<name>$opid</name>
		<name>$opshort</name>
	    </option>
EOT

	gen_mandatory_option($type);

	print XML <<EOT;
	</group>
    </command>
</cloxx>
EOT
	$short_command = "$cmdid $short_command";
	$long_command  = "$cmdid $long_command";
	$blank_command = "$cmdid";
	runtest("option($type) in group in command");
    }
}
################################################################################
sub test_command {
    my $cmdid = get_id();
    my $opid  = get_id();
    my $opshort = get_short_name();

    reset_test();

    print XML <<EOT;
<cloxx>
    <config command="mandatory"/>
    <command id="$cmdid">
	<name>$cmdid</name>
	<option id="$opid" type="flag">
	    <name>$opid</name>
	    <name>$opshort</name>
	</option>
    </command>
</cloxx>
EOT

    $short_command = "$cmdid -$opshort";
    $long_command  = "$cmdid --$opid";
    $blank_command = '';
    runtest("mandatory command");
}
################################################################################
sub runtest {
    my $test_name = shift;
    close XML;

    test_start("$test_name/clo++");
    run_cloxx();
    if ($? == 0) {
	test_passed();
    } else {
	test_failed();
	return;
    }

    test_start("$test_name/compile");
    system("$ENV{CXX} $ENV{CXXFLAGS} -o $exefile $cxxfile clo.cxx > /dev/null 2>&1");
    if ($? == 0) {
	test_passed();
    } else {
	test_failed();
	return;
    }

    test_start("$test_name/no options");
    system("./$exefile $blank_command > /dev/null 2>&1");
    if ($? == 0) {
	test_failed();
	return;
    } else {
	test_passed();
    }

    test_start("$test_name/$exefile $short_command");
    system("./$exefile $short_command > /dev/null 2>&1");
    if ($? == 0) {
	test_passed();
    } else {
	test_failed();
	return;
    }

    test_start("$test_name/$exefile $long_command");
    system("./$exefile $long_command > /dev/null 2>&1");
    if ($? == 0) {
	test_passed();
    } else {
	test_failed();
	return;
    }
}
################################################################################
sub reset_test {
    unlink($exefile, "clo.h", "clo.cxx");
    system("rm -f *.o");
    open(XML, ">$xmlfile") || die $!;
    reset_id_pool();
}
################################################################################
sub gen_mandatory_option {
    my $type = shift;
    my $id = get_id();
    my $short = get_short_name();
    my $value = '';

    my $extra = '';
    if ($type eq 'enum') { $extra = qq(<enum id="a" name="a"/>); }

    print XML <<EOT;
	<option id="$id" type="$type" mandatory="yes">
	    <name>$id</name>
	    <name>$short</name>
	    $extra
	</option>
EOT
    
    if	    ($type eq 'bool')	{ $value = 'true'   }
    elsif   ($type eq 'enum')	{ $value = 'a'	    }
    elsif   ($type eq 'int')	{ $value = 1	    }
    elsif   ($type eq 'double')	{ $value = 1	    }
    elsif   ($type eq 'string')	{ $value = 'a'	    }

    $short_command = "-$short $value";
    $long_command  = "--$id $value";
}
