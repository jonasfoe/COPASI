#! /usr/bin/perl -w
######################################################################
# Copyright (C) 2002-2003 Peter J Jones (pjones@pmade.org)
# All Rights Reserved
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 3. Neither the name of the Author nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
# OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
# USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
################################################################################
#
# test_groups.pl (Test <group>s)
# Peter J Jones (pjones@pmade.org)
#
################################################################################
#
# Includes
#
################################################################################
use strict;
use Cwd qw(chdir cwd);
require "../utility/test_harness.pl";
################################################################################
#
# Constants
#
################################################################################
use constant DATE		=> 'Tue Apr  9 23:39:38 2002';
use constant ID			=> '$Id: test_groups.pl,v 1.3 2003/01/12 22:14:09 pjones Exp $';
################################################################################
#
# Global Variables
#
################################################################################
my $sandbox = get_sandbox();
my $xmlfile = get_xmlfile();
my $cxxfile = "main.cxx";
my $exefile = "test";

my @option_types = qw(flag bool enum int double string);
my @fail_commands;
my @pass_commands;

$ENV{CXX} ||= "c++";
$ENV{CXXFLAGS} ||= '';
################################################################################
#
# Code Start
#
################################################################################
unless (chdir $sandbox) {
    print STDERR "$0: can't chdir into $sandbox: $!\n";
    exit 1;
}

open(CXX, ">$cxxfile") || die $!;
print CXX <<EOT;
#include "clo.h"
int main (int argc, char *argv[]) {
    try { clo::parser parser; parser.parse(argc, argv); }
    catch ( ... ) { return 1; }
    return 0;
}
EOT
close CXX;

test_and_group();
test_or_group();
test_xor_group();
test_xor_group_not_strict();
test_and_group_in_command();
test_or_group_in_command();
test_xor_group_in_command();
test_xor_group_in_command_not_strict();

################################################################################
sub test_and_group {
    reset_test();

    print XML qq(<cloxx>\n);
    gen_and_group();
    print XML qq(</cloxx>);

    runtest("and");
}
################################################################################
sub test_and_group_in_command {
    reset_test();
    my $cmdid = get_id();

    print XML qq(<cloxx>\n<command id="$cmdid"><name>$cmdid</name>\n);
    gen_and_group();
    print XML qq(</command>\n</cloxx>);

    $_ = "$cmdid $_" foreach (@pass_commands);
    $_ = "$cmdid $_" foreach (@fail_commands);
    runtest("and in command");
}
################################################################################
sub test_or_group {
    reset_test();

    print XML qq(<cloxx>\n);
    gen_or_group();
    print XML qq(</cloxx>);

    runtest("or");
}
################################################################################
sub test_or_group_in_command {
    reset_test();
    my $cmdid = get_id();

    print XML qq(<cloxx>\n<command id="$cmdid"><name>$cmdid</name>\n);
    gen_or_group();
    print XML qq(</command>\n</cloxx>);

    $_ = "$cmdid $_" foreach (@pass_commands);
    $_ = "$cmdid $_" foreach (@fail_commands);
    runtest("or in command");
}
################################################################################
sub test_xor_group {
    reset_test();
    
    print XML qq(<cloxx>\n);
    gen_xor_group();
    print XML qq(</cloxx>);

    runtest("xor");
}
################################################################################
sub test_xor_group_in_command {
    reset_test();
    my $cmdid = get_id();

    print XML qq(<cloxx>\n<command id="$cmdid"><name>$cmdid</name>\n);
    gen_xor_group();
    print XML qq(</command>\n</cloxx>);

    $_ = "$cmdid $_" foreach (@pass_commands);
    $_ = "$cmdid $_" foreach (@fail_commands);
    runtest("xor in command");
}
################################################################################
sub test_xor_group_not_strict {
    reset_test();
    
    print XML qq(<cloxx>\n);
    gen_xor_group_not_strict();
    print XML qq(</cloxx>);

    runtest("xor not-strict");
}
################################################################################
sub test_xor_group_in_command_not_strict {
    reset_test();
    my $cmdid = get_id();

    print XML qq(<cloxx>\n<command id="$cmdid"><name>$cmdid</name>\n);
    gen_xor_group_not_strict();
    print XML qq(</command>\n</cloxx>);

    $_ = "$cmdid $_" foreach (@pass_commands);
    $_ = "$cmdid $_" foreach (@fail_commands);
    runtest("xor in command not-strict");
}
################################################################################
sub reset_test {
    unlink($exefile, "clo.h", "clo.cxx");
    system("rm -f *.o");
    open(XML, ">$xmlfile") || die $!;
    undef @fail_commands;
    undef @pass_commands;
    reset_id_pool();
}
################################################################################
sub runtest {
    close XML;
    my $testname = shift;

    test_start("$testname/clo++");
    run_cloxx();
    $? == 0 ? test_passed() : test_failed();

    test_start("$testname/compile");
    system("$ENV{CXX} $ENV{CXXFLAGS} -o $exefile $cxxfile clo.cxx > /dev/null 2>&1");
    $? == 0 ? test_passed() : test_failed();

    foreach my $pass_command (@pass_commands) {
	test_start("$testname/passtest $pass_command");
	system("./$exefile $pass_command > /dev/null 2>&1");
	$? == 0 ? test_passed() : test_failed();
    }

    foreach my $fail_command (@fail_commands) {
	test_start("$testname/failtest $fail_command");
	system("./$exefile $fail_command > /dev/null 2>&1");
	$? == 0 ? test_failed() : test_passed();
    }
}
################################################################################
sub gen_and_group {
    my $grpid = get_id();
    my (@short_options, @long_options);

    print XML qq(<group id="$grpid" type="and">\n);
    gen_options(\@short_options, \@long_options);
    print XML qq(</group>\n);

    for (my $i=0; $i<@short_options; ++$i) {
	my $pass_string = '';

	for (my $skip=0; $skip<@short_options; ++$skip) {
	    my $fail_string = '';

	    if ($skip == $i) {
		$pass_string .= "$short_options[$skip] ";
	    } else {
		$pass_string .= "$long_options[$skip] ";
	    }

	    for (my $element=0; $element<@short_options; ++$element) {
		next if ($element == $skip);

		if ($element == $i) {
		    $fail_string .= "$short_options[$element] ";
		} else {
		    $fail_string .= "$long_options[$element] ";
		}
	    }

	    push(@fail_commands, $fail_string);
	}

	push(@pass_commands, $pass_string);
    }
}
################################################################################
sub gen_or_group {
    my $grpid = get_id();
    my (@short_options, @long_options);

    print XML qq(<group id="$grpid" type="or" mandatory="yes">\n);
    gen_options(\@short_options, \@long_options);
    print XML qq(</group>\n);

    push(@fail_commands, "");

    for (my $i=0; $i<@short_options; ++$i) {
	push(@pass_commands, $short_options[$i], $long_options[$i]);
	
	my $command = '';
	for (my $op=0; $op<@short_options; ++$op) {
	    $command .= $op == $i ? $short_options[$op] : $long_options[$op];
	    $command .= " ";
	}

	push(@pass_commands, $command);
    }
}
################################################################################
sub gen_xor_group {
    my $grpid = get_id();
    my (@short_options, @long_options);

    print XML qq(<group id="$grpid" type="xor" mandatory="yes" strict="yes">\n);
    gen_options(\@short_options, \@long_options);
    print XML qq(</group>\n);

    push(@fail_commands, "");

    for (my $i=0; $i<@short_options; ++$i) {
	push(@pass_commands, $short_options[$i], $long_options[$i]);

	if ($i != 0) {
	    push(@fail_commands, join(' ', @short_options[0..$i]));
	    push(@fail_commands, join(' ', @long_options[0..$i]));
	}
    }
}
################################################################################
sub gen_xor_group_not_strict {
    my $grpid = get_id();
    my (@short_options, @long_options);

    print XML qq(<group id="$grpid" type="xor" mandatory="yes" strict="no">\n);
    gen_options(\@short_options, \@long_options);
    print XML qq(</group>\n);

    push(@fail_commands, "");

    for (my $i=0; $i<@short_options; ++$i) {
	push(@pass_commands, $short_options[$i], $long_options[$i]);

	if ($i != 0) {
	    push(@pass_commands, join(' ', @short_options[0..$i]));
	    push(@pass_commands, join(' ', @long_options[0..$i]));
	}
    }
}
################################################################################
sub gen_options {
    my ($short_options, $long_options) = @_;

    foreach my $type (@option_types) {
	foreach my $mod (qw(none vector map)) {
	    next if ($type eq 'flag' && $mod ne 'none');

	    my $opid = get_id();
	    my $opshort = get_short_name();
	    my $value = '';
	    my $extra = '';

	    if ($type eq 'enum') {$extra = '<enum id="a" name="a"/>'}
	    print XML qq(<option id="$opid" type="$type" modifier="$mod">\n);
	    print XML qq(<name>$opid</name><name>$opshort</name>$extra\n);
	    print XML qq(</option>\n);

	    if		($type eq 'bool')	{ $value = 'true'   }
	    elsif	($type eq 'enum')	{ $value = 'a'	    }
	    elsif	($type eq 'int')	{ $value = 1	    }
	    elsif	($type eq 'double')	{ $value = 1	    }
	    elsif	($type eq 'string')	{ $value = 'a'	    }

	    if ($mod eq 'map') { $value = "x=$value"; }
	    push(@$short_options, "-$opshort $value");
	    push(@$long_options,  "--$opid $value");
	}
    }
}
