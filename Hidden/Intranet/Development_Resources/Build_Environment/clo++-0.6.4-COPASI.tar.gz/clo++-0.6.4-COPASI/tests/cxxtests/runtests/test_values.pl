#! /usr/bin/perl -w
######################################################################
# Copyright (C) 2002-2003 Peter J Jones (pjones@pmade.org)
# All Rights Reserved
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 3. Neither the name of the Author nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
# OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
# USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
################################################################################
#
# test_values.pl (Test option value parsing)
# Peter J Jones (pjones@pmade.org)
#
################################################################################
#
# Includes
#
################################################################################
use strict;
use Cwd qw(chdir cwd);
require "../utility/test_harness.pl";
################################################################################
#
# Constants
#
################################################################################
use constant DATE		=> 'Tue Apr  9 23:39:38 2002';
use constant ID			=> '$Id: test_values.pl,v 1.2 2003/01/12 22:14:09 pjones Exp $';
################################################################################
#
# Global Variables
#
################################################################################
my $sandbox = get_sandbox();
my $xmlfile = get_xmlfile();
my $cxxfile = "main.cxx";
my $exefile = "test";

my @option_types = qw(flag bool enum int double string);
my @commands;
my @expect;

$ENV{CXX} ||= "c++";
$ENV{CXXFLAGS} ||= '';
################################################################################
#
# Code Start
#
################################################################################
unless (chdir $sandbox) {
    print STDERR "$0: can't chdir into $sandbox: $!\n";
    exit 1;
}

open(CXX, ">$cxxfile") || die $!;
print CXX <<EOT;
#include "clo.h"
#include <iostream>
#include <iterator>
#include <algorithm>

int main (int argc, char *argv[]) {
    try {
	clo::parser parser; parser.parse(argc, argv); 
	const clo::options &options = parser.get_options();
	const clo::option_locations &locations = parser.get_locations();

EOT

open(XML, ">$xmlfile") || die $!;
print XML <<EOT;
<cloxx>
    <config>
	<true>true</true>
	<true>yes</true>
	<true>on</true>
	<false>false</false>
	<false>no</false>
	<false>off</false>
    </config>
    
    <options>
EOT

gen_option_flag();
gen_option_bool();
gen_option_enum();
gen_option_int();
gen_option_double();
gen_option_string();

print XML <<EOT;
    </options>
</cloxx>
EOT
close XML;

print CXX <<EOT;
    } catch ( ... ) { return 1; }

    return 0;
}
EOT
close CXX;

test_start("options/clo++");
run_cloxx();
$? == 0 ? test_passed() : test_failed();

test_start("options/compile");
system("$ENV{CXX} $ENV{CXXFLAGS} -o $exefile $cxxfile clo.cxx > /dev/null 2>&1");
$? == 0 ? test_passed() : test_failed();

my $output;

for (my $i=0; $i<@commands; ++$i) {
    test_start("options/$commands[$i]");
    chomp($output = `./$exefile $commands[$i] 2>&1`);
    foreach ($output, $expect[$i]) {s/^\s+//; s/\s+$//;}

    # a map has no order
    if ($expect[$i] =~ /\w=\w/) {
	my @e = split(/\s+/, $expect[$i]);
	$expect[$i] = join(' ', sort(@e));

	my @o = split(/\s+/, $output);
	$output = join(' ', sort(@o));
    }

    if ($output eq $expect[$i]) {
	test_passed();
    } else {
	if (open(FAIL, ">failed_match")) {
	    print FAIL "$output\n";
	    print FAIL "$expect[$i]\n";
	    close FAIL;
	}

	test_failed();
    }
}
################################################################################
sub gen_option {
    my $opid = shift;
    my $opshort = shift;
    my $type = shift;
    my $mod  = shift;

    print XML qq(<option id="$opid" type="$type" modifier="$mod">\n);
    print XML qq(<name>$opid</name><name>$opshort</name>\n);
    print XML qq(</option>\n);
}
################################################################################
sub gen_option_flag {
    my $options = shift || "options";
    my $locations = shift || "locations";
    my $opid = get_id();
    my $opshort = get_short_name();

    gen_option($opid, $opshort, "flag", "none");
    print CXX qq|if ($locations.$opid) std::cout << $options.$opid << "\\n";\n|;

    push(@commands, "--$opid");
    push(@expect, "1");

    push(@commands, "-$opshort");
    push(@expect, "1");

    push(@commands, "--$opid -$opshort");
    push(@expect, "0");
}
################################################################################
sub gen_option_bool {
    my $options = shift || "options";
    my $locations = shift || "locations";
    my $opid = get_id();
    my $opshort = get_short_name();

    gen_option($opid, $opshort, "bool", "none");
    print CXX qq|if ($locations.$opid) std::cout << $options.$opid << "\\n";\n|;

    foreach my $word (qw(true yes on)) {
	push(@commands, "--$opid $word");
	push(@expect,   "1");
	push(@commands, "-$opshort $word");
	push(@expect,   "1");
    }

    foreach my $word (qw(false no off)) {
	push(@commands, "--$opid=$word");
	push(@expect,   "0");
	push(@commands, "-$opshort$word");
	push(@expect,   "0");
    }

    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "bool", "vector");
    print CXX qq|if ($locations.$opid) {\n|;
    print CXX qq|std::copy($options.$opid.begin(), $options.$opid.end(), std::ostream_iterator<bool>(std::cout, " "));|;
    print CXX qq|std::cout << "\\n";}\n|;

    my $expect = '';
    my $command = '';
    foreach my $count (0 .. 10) {
	foreach my $word (qw(true yes on false no off)) {
	    my $tmp = $word =~ /true|yes|on/ ? '1': '0';
	    $command .= "--$opid $word -$opshort $word ";
	    $expect  .= "$tmp $tmp ";
	}
    }

    push(@commands, $command);
    push(@expect, $expect);


    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "bool", "map");
    print CXX qq|if ($locations.$opid) {\n|;
    print CXX qq|std::map<std::string, bool>::const_iterator i($options.$opid.begin()), end($options.$opid.end());\n|;
    print CXX qq|for (; i != end; ++i) std::cout << i->first << "=" << i->second << " ";\n|;
    print CXX qq|std::cout << "\\n";}\n|;


    $expect = '';
    $command = '';

    foreach my $key (qw(one two three four five six seven eight nine ten)) {
	$command .= "--$opid $key=true -$opshort s$key=false ";
	$expect  .= "$key=1 s$key=0 ";
    }

    push(@commands, $command);
    push(@expect, $expect);
}
################################################################################
sub gen_option_enum {
    my $options = shift || "options";
    my $locations = shift || "locations";
    my $opid = get_id();
    my $opshort = get_short_name();

    print XML <<EOT;
<option id="$opid" type="enum">
    <name>$opid</name>
    <name>$opshort</name>
    <enum id="a" name="a"/>
    <enum id="b" name="b"/>
    <enum id="c" name="c"/>
</option>
EOT

    print CXX <<EOT;
if ($locations.$opid) {
    switch ($options.$opid) {
	case clo::${opid}_a:
	    std::cout << "a\\n";
	    break;
	case clo::${opid}_b:
	    std::cout << "b\\n";
	    break;
	case clo::${opid}_c:
	    std::cout << "c\\n";
	    break;
    }
}
EOT

    foreach my $letter (qw(a b c)) {
	push(@commands, "--$opid $letter");
	push(@expect,   "$letter");
	push(@commands, "-$opshort $letter");
	push(@expect,   "$letter");
    }

    $opid = get_id();
    $opshort = get_short_name();

    print XML <<EOT;
<option id="$opid" type="enum" modifier="vector">
    <name>$opid</name>
    <name>$opshort</name>
    <enum id="a" name="a"/>
    <enum id="b" name="b"/>
    <enum id="c" name="c"/>
</option>
EOT

    print CXX <<EOT;
if ($locations.$opid) {
    std::vector<clo::${opid}_enum>::const_iterator i($options.$opid.begin()), end($options.$opid.end());
    for (; i != end; ++i) {
	switch (*i) {
	    case clo::${opid}_a:
		std::cout << "a ";
		break;
	    case clo::${opid}_b:
		std::cout << "b ";
		break;
	    case clo::${opid}_c:
		std::cout << "c ";
		break;
	}
    }
    std::cout << "\\n";
}
EOT

    my $command = '';
    my $expect = '';
    foreach my $count (0..10) {
	foreach my $letter (qw(a b c)) {
	    $command .= "--$opid $letter -$opshort$letter ";
	    $expect  .= "$letter $letter ";
	}
    }

    push(@commands, $command);
    push(@expect,   $expect);

    $opid = get_id();
    $opshort = get_short_name();

    print XML <<EOT;
<option id="$opid" type="enum" modifier="map">
    <name>$opid</name>
    <name>$opshort</name>
    <enum id="a" name="a"/>
    <enum id="b" name="b"/>
    <enum id="c" name="c"/>
</option>
EOT

    print CXX <<EOT;
if ($locations.$opid) {
    std::map<std::string, clo::${opid}_enum>::const_iterator i($options.$opid.begin()), end($options.$opid.end());
    for (; i != end; ++i) {
	switch (i->second) {
	    case clo::${opid}_a:
		std::cout << i->first << "=" << "a ";
		break;
	    case clo::${opid}_b:
		std::cout << i->first << "=" << "b ";
		break;
	    case clo::${opid}_c:
		std::cout << i->first << "=" << "c ";
		break;
	}
    }
    std::cout << "\\n";
}
EOT

    $command = '';
    $expect = '';
    srand(time());
    foreach my $key (qw(jan feb mar apr may jun jul aug sep oct nov dec)) {
	my $letter = (qw(a b c))[int rand(3)];
	$command .= "--$opid $key=$letter -${opshort}s$key=$letter ";
	$expect  .= "$key=$letter s$key=$letter ";
    }

    push(@commands, $command);
    push(@expect,   $expect);
}
################################################################################
sub gen_option_int {
    my $options = shift || "options";
    my $locations = shift || "locations";
    my $opid = get_id();
    my $opshort = get_short_name();

    gen_option($opid, $opshort, "int", "none");
    print CXX qq|if ($locations.$opid) std::cout << $options.$opid << "\\n";\n|;

    push(@commands, "--$opid 10");
    push(@expect, "10");

    push(@commands, "-$opshort 0x0a");
    push(@expect, "10");


    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "int", "vector");
    print CXX <<EOT;
if ($locations.$opid) {
    std::copy($options.$opid.begin(), $options.$opid.end(),
	std::ostream_iterator<int>(std::cout, " "));
    std::cout << "\\n";
}
EOT

    my $command = '';
    my $expect  = '';

    foreach my $count (0..10) {
	$command .= "--$opid $count -$opshort$count ";
	$expect  .= "$count $count ";
    }

    push(@commands, $command);
    push(@expect, $expect);

    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "int", "map");
    print CXX <<EOT;
if ($locations.$opid) {
    std::map<std::string, int>::const_iterator i($options.$opid.begin()), end($options.$opid.end());
    for (; i != end; ++i) std::cout << i->first << "=" << i->second << " ";
    std::cout << "\\n";
}
EOT
    
    $command = '';
    $expect = '';
    
    srand(time());
    foreach my $word (qw(peter rebekah jordan abigail jason jane jones)) {
	my $number = int rand(100);
	$command .= "--$opid=$word=$number -$opshort s$word=$number ";
	$expect  .= "$word=$number s$word=$number ";
    }

    push(@commands, $command);
    push(@expect, $expect);
}
################################################################################
sub gen_option_double {
    my $options = shift || "options";
    my $locations = shift || "locations";
    my $opid = get_id();
    my $opshort = get_short_name();

    gen_option($opid, $opshort, "double", "none");
    print CXX qq|if ($locations.$opid) std::cout << $options.$opid << "\\n";\n|;

    my $number = 0.12;
    push(@commands, "--$opid $number");
    push(@expect, "$number");

    push(@commands, "-$opshort $number");
    push(@expect, "$number");
    
    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "double", "vector");
    print CXX <<EOT;
if ($locations.$opid) {
    std::copy($options.$opid.begin(), $options.$opid.end(),
	std::ostream_iterator<double>(std::cout, " "));
    std::cout << "\\n";
}
EOT

    my $command = '';
    my $expect = '';

    srand(time());
    foreach (0..10) {
	$number = sprintf("%.4f", rand(100));
	$number =~ s/0+$//;
	$command .= "--$opid $number -$opshort $number ";
	$expect  .= "$number $number ";
    }

    push(@commands, $command);
    push(@expect, $expect);

    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "double", "map");
    print CXX <<EOT;
if ($locations.$opid) {
    std::map<std::string, double>::const_iterator i($options.$opid.begin()), end($options.$opid.end());
    for (; i != end; ++i) std::cout << i->first << "=" << i->second << " ";
    std::cout << "\\n";
}
EOT

    $command = '';
    $expect  = '';

    foreach my $word (qw(freebsd netbsd openbsd macosx bsdos)) {
	$number = sprintf("%.4f", rand(100));
	$number =~ s/0+$//;
	$command .= "--$opid $word=$number -$opshort s$word=$number ";
	$expect  .= "$word=$number s$word=$number ";
    }

    push(@commands, $command);
    push(@expect, $expect);
}
################################################################################
sub gen_option_string {
    my $options = shift || "options";
    my $locations = shift || "locations";
    my $opid = get_id();
    my $opshort = get_short_name();

    gen_option($opid, $opshort, "string", "none");
    print CXX qq|if ($locations.$opid) std::cout << $options.$opid << "\\n";\n|;

    push(@commands, "--$opid hello");
    push(@expect, "hello");

    push(@commands, "-$opshort world");
    push(@expect, "world");

    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "string", "vector");
    print CXX <<EOT;
if ($locations.$opid) {
    std::copy($options.$opid.begin(), $options.$opid.end(),
	std::ostream_iterator<std::string>(std::cout, " "));
    std::cout << "\\n";
}
EOT

    my $command = '';
    my $expect  = '';

    foreach (0..10) {
	foreach my $word (qw(sunday monday tuesday wednesday thursday friday saturday)) {
	    $command .= "--$opid $word -$opshort $word ";
	    $expect  .= "$word $word ";
	}
    }

    push(@commands, $command);
    push(@expect,   $expect);

    $opid = get_id();
    $opshort = get_short_name();

    gen_option($opid, $opshort, "string", "map");
    print CXX <<EOT;
if ($locations.$opid) {
    std::map<std::string, std::string>::const_iterator i($options.$opid.begin()), end($options.$opid.end());
    for (; i != end; ++i) std::cout << i->first << "=" << i->second << " ";
    std::cout << "\\n";
}
EOT

    $command = '';
    $expect  = '';

    srand(time());
    foreach my $key (qw(usaf amex motorola dac di cwdi exodus)) {
	my $value = (qw(sucks okay cool))[rand(3)];
	$command .= "--$opid $key=$value -$opshort s$key=$value ";
	$expect  .= "$key=$value s$key=$value ";
    }

    push(@commands, $command);
    push(@expect, $expect);
}
