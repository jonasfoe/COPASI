#include <iostream>
#include "clo.h"

int main (int argc, char *argv[]) {
    try {

	/*
	 * create a command line parser class and then tell it to parse your
	 * command line.
	 */
	clo::parser parser;
	parser.parse(argc, argv);

	/*
	 * get the struct of options from the parser class so that you can
	 * access the option values.
	 */
	const clo::options &options = parser.get_options();

	for (int i=0; i < options.count; ++i)
	    std::cout << options.message << "\n";

    } catch (std::exception &e) {
	std::cerr << argv[0] << ": " << e.what() << "\n";
	return 1;
    }

    return 0;
}
