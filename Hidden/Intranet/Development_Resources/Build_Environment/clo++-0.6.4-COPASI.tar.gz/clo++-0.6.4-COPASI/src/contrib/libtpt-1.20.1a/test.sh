#!/bin/sh

chdir test
./test.sh
chdir ..
