#/bin/sh

echo buffertest
./buffertest buffertest.cxx
echo Parser test
./test1 54
echo IParser test
./test2 2
