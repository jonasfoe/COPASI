/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains common constants and function objects for cloxx.
**/

#ifndef __cloxx_common_h__
#define __cloxx_common_h__

#include <xmlwrapp/node.h>
#include <cxxtools/strutil.h>
#include <list>
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>

namespace {

    const char const_tag_option[]	= "option";
    const char const_tag_group[]	= "group";
    const char const_tag_command[]	= "command";
    const char const_tag_name[]		= "name";
    const char const_tag_comment[]	= "comment";
    const char const_tag_description[]	= "description";
    const char const_tag_para[]		= "para";
    const char const_attr_id[]		= "id";
    const char const_attr_type[]	= "type";
    const char const_attr_strict[]	= "strict";
    const char const_attr_mandatory[]	= "mandatory";

    const char const_bool_true[]	= "yes";
    const char const_bool_false[]	= "no";

    /*
     * The find_by_id template class is a function object that will return
     * true when the given id matches the return value of get_id(). I use it
     * with std::list::remove_if
     */
    template <typename T> class find_by_id {
    public:
	find_by_id (const char *id) : id_(id)
	{ }
	bool operator() (const T &t)
	{ return std::strcmp(id_, t.get_id()) == 0; }
    private:
	const char *id_;
    };

    /*
     * The tpt_export template class is a function object that I use with
     * std::for_each to call export_to_tpt for each object in a list.
     */
    template <typename T> class tpt_export {
    public:
	explicit tpt_export (TPT::Object &obj) : obj_(obj)
	{ }

	void operator() (const T &t)
	{ t.export_to_tpt(obj_); }
    private:
	TPT::Object &obj_;
    };

    /*
     * template class for sending to std::partition to find out if a string
     * is a short name or long name
     */
    struct name_is_short {
	bool operator() (const std::string &s)
	{ return s.size() == 1; }
    };

    /*
     * a function to generate an option signature
     */
    void generate_signature (const std::list<std::string> &option_names, std::string &signature) {
	std::vector<std::string> names(option_names.begin(), option_names.end());
	std::sort(names.begin(), names.end());
	std::vector<std::string>::iterator i = std::stable_partition(names.begin(), names.end(), name_is_short());

	std::vector<std::string>::iterator first(names.begin()), last(names.end());

	for (; first != i; ++first) first->insert(0, "-");
	for (; i != last; ++i) i->insert(0, "--");

	signature = cxxtools::join(std::string(", "), names.begin(), names.end());
    }

    bool set_bool_from_string (bool &b, const char *s) {
	if (std::strcmp(s, const_bool_true) == 0) {
	    b = true; return true;
	} else if (std::strcmp(s, const_bool_false) == 0) {
	    b = false; return true;
	}

	return false;
    }

    /*
     * wrapper around for_each
     */
    template <typename it_, typename function_> 
    void nested_for_each (it_ begin, it_ end, function_ f) {
	for(; begin != end; ++begin) std::for_each(begin->get_options().begin(), begin->get_options().end(), f);
    }

    const char* get_string_from_bool (bool b)
    { return b ? const_bool_true : const_bool_false; }

    void import_description (const xml::node &desc_node, std::list<std::string> &paras) {
	xml::node::const_iterator i(desc_node.begin()), end(desc_node.end());
	for (; i != end; ++i) {
	    if (std::strcmp(i->get_name(), const_tag_para) == 0) {
		std::string para = i->get_content();
		cxxtools::normalize(para);
		paras.push_back(para);
	    }
	}
    }

    void export_description (xml::node &n, const std::list<std::string> &paras) {
	if (paras.empty()) return;

	xml::node desc_node(const_tag_description);

	std::list<std::string>::const_iterator para_it(paras.begin()), para_end(paras.end());
	for (; para_it != para_end; ++para_it) desc_node.push_back(xml::node(const_tag_para, para_it->c_str()));

	n.push_back(desc_node);
    }

    void export_description (TPT::Object &o, const std::list<std::string> &paras) {
	if (paras.empty()) return;

	TPT::Object::PtrType desc_obj = new TPT::Object(TPT::Object::type_array);
	std::list<std::string>::const_iterator para_it(paras.begin()), para_end(paras.end());
	for (; para_it != para_end; ++para_it) desc_obj.get()->array().push_back(new TPT::Object(*para_it));

	o.hash()[const_tag_description] = desc_obj;
    }

} // end anonymous namespace
#endif
