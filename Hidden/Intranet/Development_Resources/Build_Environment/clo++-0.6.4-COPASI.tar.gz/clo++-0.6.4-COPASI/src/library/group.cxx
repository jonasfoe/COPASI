/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::group class.
**/

// cloxx includes
#include <cloxx/group.h>
#include <cloxx/option.h>
#include "common.h"

// xmlwrapp includes
#include <xmlwrapp/xmlwrapp.h>

// cxxtools includes
#include <cxxtools/strutil.h>

// standard includes
#include <list>
#include <memory>
#include <string>
#include <cstring>
#include <algorithm>
#include <stdexcept>

//####################################################################
namespace {
    const char const_type_xor[]		= "xor";
    const char const_type_or[]		= "or";
    const char const_type_and[]		= "and";
}
//####################################################################
class cloxx::group::pimpl {
public:
    pimpl (void)
	: type_(type_xor), strict_(false), mandatory_(false)
    { }

    void import_from_xml (const xml::node &n);
    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;
    void set_id (const char *id);
    void remove_option (const char *id);

    void set_type (group::types t)			{ type_ = t;		    }
    void set_strict (bool strict)			{ strict_ = strict;	    }
    void set_mandatory (bool mandatory)			{ mandatory_ = mandatory;   }
    void add_option (const option &o)			{ options_.push_back(o);    }
    const std::list<option>& get_options (void) const	{ return options_;	    }
    const char* get_id (void) const			{ return id_.c_str();	    }
    group::types get_type (void) const			{ return type_;		    }
    bool get_strict (void) const			{ return strict_;	    }
    bool get_mandatory (void) const			{ return mandatory_;	    }
private:
    group::types type_;
    bool strict_;
    bool mandatory_;
    std::string id_;
    std::list<option> options_;

    void set_type_from_string (const char *t);
    void set_strict_from_string (const char *strict);
    void set_mandatory_from_string (const char *mandatory);
    const char* get_type_as_string (void) const;
    const char* get_strict_as_string (void) const;
    const char* get_mandatory_as_string (void) const;
};
//####################################################################
cloxx::group::group (const xml::node &n) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->import_from_xml(n);
    ap.release();
}
//####################################################################
cloxx::group::group (const char *id) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->set_id(id);
    ap.release();
}
//####################################################################
cloxx::group::group (const group &other) {
    pimpl_ = new pimpl(*(other.pimpl_));
}
//####################################################################
cloxx::group& cloxx::group::operator= (const group &other) {
    group tmp(other);
    swap(tmp);
    return *this;
}
//####################################################################
void cloxx::group::swap (group &other) {
    std::swap(pimpl_, other.pimpl_);
}
//####################################################################
cloxx::group::~group (void) {
    delete pimpl_;
}
//####################################################################
/*
 * Bridge Function
 */
void cloxx::group::export_to_xml (xml::node &n) const			{ pimpl_->export_to_xml(n);	    }
void cloxx::group::export_to_tpt (TPT::Object &o) const			{ pimpl_->export_to_tpt(o);	    }
void cloxx::group::set_id (const char *id)				{ pimpl_->set_id(id);		    }
void cloxx::group::set_type (types t)					{ pimpl_->set_type(t);		    }
void cloxx::group::set_strict (bool strict)				{ pimpl_->set_strict(strict);	    }
void cloxx::group::set_mandatory (bool mandatory)			{ pimpl_->set_mandatory(mandatory); }
void cloxx::group::add_option (const option &o)				{ pimpl_->add_option(o);	    }
void cloxx::group::remove_option (const char *id)			{ pimpl_->remove_option(id);	    }
const std::list<cloxx::option>& cloxx::group::get_options (void) const	{ return pimpl_->get_options();	    }
const char* cloxx::group::get_id (void) const				{ return pimpl_->get_id();	    }
cloxx::group::types cloxx::group::get_type (void) const			{ return pimpl_->get_type();	    }
bool cloxx::group::get_strict (void) const				{ return pimpl_->get_strict();	    }
bool cloxx::group::get_mandatory (void) const				{ return pimpl_->get_mandatory();   }
//####################################################################
void cloxx::group::pimpl::import_from_xml (const xml::node &n) {
    xml::attributes::const_iterator id_it(n.get_attributes().find(const_attr_id));
    set_id(id_it == n.get_attributes().end() ? 0 : id_it->get_value());

    xml::attributes::const_iterator type_it(n.get_attributes().find(const_attr_type));
    set_type_from_string(type_it == n.get_attributes().end() ? 0 : type_it->get_value());

    xml::attributes::const_iterator strict_it(n.get_attributes().find(const_attr_strict));
    if (strict_it != n.get_attributes().end()) set_strict_from_string(strict_it->get_value());

    xml::attributes::const_iterator mandatory_it(n.get_attributes().find(const_attr_mandatory));
    if (mandatory_it != n.get_attributes().end()) set_mandatory_from_string(mandatory_it->get_value());

    xml::node::const_iterator i(n.begin()), end(n.end());
    for (; i != end; ++i) {
	if (std::strcmp(i->get_name(), const_tag_option) == 0) {
	    options_.push_back(option(*i));
	}
    }

    if (options_.size() < 2) {
	std::string error("group '"); error += id_; error += "' does not have enough options";
	throw std::runtime_error(error);
    }

    if (type_ == type_or && !mandatory_) {
	std::string error("group '"); error += id_; error += "' is type 'or' but is not mandatory";
	throw std::runtime_error(error);
    }

    if (type_ == type_or && strict_) {
	std::string error("group '"); error += id_; error += "' is type 'or' and is strict, use xor instead";
	throw std::runtime_error(error);
    }

    if (type_ == type_and && mandatory_) {
	std::string error("group '"); error += id_; error += "' is type 'and' so it can't be mandatory";
	throw std::runtime_error(error);
    }
}
//####################################################################
void cloxx::group::pimpl::export_to_xml (xml::node &n) const {
    n.get_attributes().insert(const_attr_id, id_.c_str());
    n.get_attributes().insert(const_attr_type, get_type_as_string());
    n.get_attributes().insert(const_attr_strict, get_strict_as_string());
    n.get_attributes().insert(const_attr_mandatory, get_mandatory_as_string());

    std::list<option>::const_iterator i(options_.begin()), end(options_.end());
    for (; i != end; ++i) {
	xml::node option_node(const_tag_option);
	i->export_to_xml(option_node);
	n.push_back(option_node);
    }
}
//####################################################################
void cloxx::group::pimpl::export_to_tpt (TPT::Object &o) const {
    TPT::Object::PtrType groups_hash  = o.hash()["groups"];

    TPT::Object::PtrType group_data = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::HashType &group_data_hash = group_data.get()->hash();

    group_data_hash[const_attr_id]	    = new TPT::Object(id_);
    group_data_hash[const_attr_type]	    = new TPT::Object(get_type_as_string());
    group_data_hash[const_attr_strict]	    = new TPT::Object(get_strict_as_string());
    group_data_hash[const_attr_mandatory]   = new TPT::Object(get_mandatory_as_string());

    TPT::Object::PtrType options_array = new TPT::Object(TPT::Object::type_array);
    std::list<option>::const_iterator op_it(options_.begin()), op_end(options_.end());
    for (; op_it != op_end; ++op_it) options_array.get()->array().push_back(new TPT::Object(op_it->get_id()));
    group_data_hash["options"] = options_array;

    groups_hash.get()->hash()[id_] = group_data;
    std::for_each(options_.begin(), options_.end(), tpt_export<option>(o));
}
//####################################################################
void cloxx::group::pimpl::set_id (const char *id) {
    if (!id) throw std::runtime_error("blank or missing group/@id");

    id_ = id;
    cxxtools::normalize(id_);

    if (id_.empty()) throw std::runtime_error("blank group/@id");
}
//####################################################################
void cloxx::group::pimpl::remove_option (const char *id) {
    options_.remove_if(find_by_id<option>(id));
}
//####################################################################
void cloxx::group::pimpl::set_type_from_string (const char *t) {
    if (!t) throw std::runtime_error("blank or missing group/@type");

    switch (*t) {
    case 'a':
	if (std::strcmp(t, const_type_and) == 0) {
	    type_ = type_and;
	    return;
	}
	break;
    case 'o':
	if (std::strcmp(t, const_type_or) == 0) {
	    type_ = type_or;
	    return;
	}
	break;
    case 'x':
	if (std::strcmp(t, const_type_xor) == 0) {
	    type_ = type_xor;
	    return;
	}
	break;
    }

    std::string error("unknown group/@type '"); error += t; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::group::pimpl::set_strict_from_string (const char *strict) {
    if (!strict) throw std::runtime_error("blank or missing group/@strict");
    if (set_bool_from_string(strict_, strict)) return;
    std::string error("unknown group/@strict value '"); error += strict; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::group::pimpl::set_mandatory_from_string (const char *mandatory) {
    if (!mandatory) throw std::runtime_error("blank or missing group/@mandatory");
    if (set_bool_from_string(mandatory_, mandatory)) return;
    std::string error("unknown group/@mandatory value '"); error += mandatory; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
const char* cloxx::group::pimpl::get_type_as_string (void) const {
    switch (type_) {
	case type_and:	return const_type_and;
	case type_or:	return const_type_or;
	case type_xor:	return const_type_xor;
    }

    return 0; // kill compiler warning
}
//####################################################################
const char* cloxx::group::pimpl::get_strict_as_string (void) const {
    return get_string_from_bool(strict_);
}
//####################################################################
const char* cloxx::group::pimpl::get_mandatory_as_string (void) const {
    return get_string_from_bool(mandatory_);
}
