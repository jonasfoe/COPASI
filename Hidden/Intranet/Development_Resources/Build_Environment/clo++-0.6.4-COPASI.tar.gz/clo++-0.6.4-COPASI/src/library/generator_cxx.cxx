/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::generator_cxx class.
**/

// cloxx includes
#include "generator_cxx.h"
#include <cloxx/app.h>
#include <cloxx/option.h>
#include "usage.h"
#include "tpthelper.h"
#include "common.h"

// cxxtools includes
#include <cxxtools/strutil.h>

// standard includes
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <functional>

// template include
#include "template_cxx_header.h"
#include "template_cxx_source.h"

//####################################################################
namespace {
    const char const_default_namespace[]	    = "clo";
    const char const_default_classname[]	    = "parser";
    const char const_default_source[]		    = "clo.cxx";
    const char const_default_header[]		    = "clo.h";

    const char const_var_namespace[]		    = "cxx_namespace";
    const char const_var_classname[]		    = "cxx_class";
    const char const_var_source[]		    = "cxx_source_file";
    const char const_var_header[]		    = "cxx_header_file";
    const char const_var_header_def[]		    = "cxx_header_def";
    const char const_var_usage[]		    = "cxx_usage";
    const char const_var_command_list[]		    = "cxx_command_list";
    const char const_var_command_syns[]		    = "cxx_command_syns";
    const char const_var_include[]		    = "cxx_include";
    const char const_var_include_files[]	    = "cxx_include_files";

    const char const_valid_cpp_chars[] = 
	"abcdefghijklmnopqrutuvwxyz" "ABCDEFGHIJKLMNOPQRSTUVWXYZ" "0123456789-";

    // things that we need to know for all options
    struct all_options_data {
	all_options_data (TPT::Object &obj)
	    : include_list(false), include_vector(false), include_map(false), object_(obj)
	{ }

	bool include_list;
	bool include_vector;
	bool include_map;
	std::vector<std::string> ctor_init_list;
	std::vector<std::string> option_enum;
	TPT::Object::HashType short_options;
	TPT::Object::HashType long_options;
	TPT::Object &object_;
    };

    //####################################################################
    void process_default (const cloxx::option &op, std::vector<std::string> &init_list, TPT::Object &obj);
    void process_includes (const cloxx::option &op, all_options_data &aod);
    void process_option_enum (const cloxx::option &op, TPT::Object &obj);
    void set_default_list(std::vector<std::string> &dl, TPT::Object &obj);
    void set_includes (all_options_data &aod, TPT::Object &obj);
    void gen_command_enum (const cloxx::app &application, TPT::Object &obj);
    void process_option_enum (const cloxx::option &op, std::vector<std::string> &member_list);
    void set_option_enum (const std::vector<std::string> &member_list, TPT::Object &obj);
    void process_option_size (const cloxx::option &op, all_options_data &aod);
    void set_group_id (const cloxx::group &grp, TPT::Object &obj);
    //####################################################################

    // deal with data from one option
    struct visit_option {
	visit_option(TPT::Object &obj, all_options_data &aod)
	    : aod_(aod), obj_(obj)
	{ }

	void operator() (const cloxx::option &op) {
	    process_default(op, aod_.ctor_init_list, obj_);
	    process_includes(op, aod_);
	    process_option_enum(op, aod_.option_enum);
	    process_option_size(op, aod_);
	    process_option_enum(op, obj_);
	}

	all_options_data &aod_;
	TPT::Object &obj_;
    };

    // deal with data from one group
    struct visit_group {
	visit_group(TPT::Object &obj) : obj_(obj) { }
	void operator() (const cloxx::group &grp) {
	    set_group_id(grp, obj_);
	}

	TPT::Object &obj_;
    };

    // compare ids without the default spec
    struct compare_default {
	bool operator() (const std::string &a, const std::string &b) {
	    std::string A(a.substr(0, a.find('('))), B(b.substr(0, b.find('(')));
	    return A < B;
	}
    };
} // end anonymous namespace

//####################################################################
void cloxx::generator_cxx::generate (const app &application, TPT::Object &obj) {
    all_options_data aod(obj);

    // visit all top level options
    visit_option vo1(obj, aod);
    std::for_each(application.get_options().begin(), application.get_options().end(), vo1);
    nested_for_each(application.get_groups().begin(), application.get_groups().end(), vo1);
    std::for_each(application.get_groups().begin(), application.get_groups().end(), visit_group(obj));
    set_default_list(aod.ctor_init_list, obj);
    set_option_enum(aod.option_enum, obj);
    obj.hash()["short_options"] = new TPT::Object(aod.short_options);
    obj.hash()["long_options"]  = new TPT::Object(aod.long_options);

    // set usage variables
    std::string usage_string;
    usage usage_obj(usage_string);
    usage_obj(application);
    usage_obj.make_cstring();
    obj.hash()[const_var_usage] = new TPT::Object(usage_string);

    if (!application.get_commands().empty()) {
	std::string command_list_string;
	usage command_list_usage(command_list_string);
	command_list_usage.make_command_list(application);
	command_list_usage.make_cstring();
	obj.hash()[const_var_command_list] = new TPT::Object(command_list_string);

	std::string command_syns_string;
	usage command_syns_usage(command_syns_string);
	command_syns_usage.make_command_syns(application);
	command_syns_usage.make_cstring();
	obj.hash()[const_var_command_syns] = new TPT::Object(command_syns_string);
    }
    
    // visit all command options
    std::list<command>::const_iterator
	commands_it(application.get_commands().begin()),
	commands_end(application.get_commands().end());

    for (; commands_it != commands_end; ++commands_it) {
	TPT::Object::PtrType command_obj = obj.hash()["commands"].get()->hash()[commands_it->get_id()];
	visit_option vo2(*(command_obj.get()), aod);
	aod.ctor_init_list.clear();
	aod.option_enum.clear();
	aod.short_options.clear();
	aod.long_options.clear();

	std::for_each(commands_it->get_options().begin(), commands_it->get_options().end(), vo2);
	nested_for_each(commands_it->get_groups().begin(), commands_it->get_groups().end(), vo2);
	std::for_each(commands_it->get_groups().begin(), commands_it->get_groups().end(), visit_group(*(command_obj.get())));
	set_default_list(aod.ctor_init_list, *(command_obj.get()));
	set_option_enum(aod.option_enum, *(command_obj.get()));

	command_obj.get()->hash()["short_options"] = new TPT::Object(aod.short_options);
	command_obj.get()->hash()["long_options"]  = new TPT::Object(aod.long_options);

	std::string ustring; usage u(ustring);
	u(*commands_it); u.make_cstring();
	command_obj.get()->hash()[const_var_usage] = new TPT::Object(ustring);
    }

    // help with the autothrow enum
    TPT::Object::HashType::const_iterator autothrow_it = obj.hash().find("autothrow");
    if (autothrow_it != obj.hash().end()) {
	TPT::Object::ArrayType &autothrow_array = autothrow_it->second.get()->array();
	TPT::Object::ArrayType::const_iterator at_it(autothrow_array.begin()), at_end(autothrow_array.end());
	std::vector<std::string> at_list;

	for (; at_it != at_end; ++at_it) at_list.push_back("autothrow_" + at_it->get()->scalar());
	obj.hash()["autothrow_enum"] = new TPT::Object(cxxtools::join(std::string(",\n\t"), at_list.begin(), at_list.end()));
    }

    // help with the autothelp options
    if (application.get_config().get_autohelp_state()) {
	TPT::Object::PtrType autohelp_short_names = new TPT::Object(TPT::Object::type_array);
	TPT::Object::PtrType autohelp_long_names  = new TPT::Object(TPT::Object::type_array);
	const std::list<std::string> &autohelp_names = application.get_config().get_autohelp_names();
	std::list<std::string>::const_iterator it(autohelp_names.begin()), end(autohelp_names.end());

	for (; it != end; ++it) {
	    if (it->size() == 1) autohelp_short_names.get()->array().push_back(new TPT::Object(*it));
	    else autohelp_long_names.get()->array().push_back(new TPT::Object(*it));
	}

	obj.hash()["autohelp_short_names"] = autohelp_short_names;
	obj.hash()["autohelp_long_names"]  = autohelp_long_names;
    }

    // set up some C++ specific variables
    const config::variable_table &var_table = application.get_config().get_variables();
    config::variable_table::const_iterator var_it, var_end(var_table.end());

    if ( (var_it = var_table.find(const_var_namespace)) == var_end) {
	// give this variable a default value since it was not given
	obj.hash()[const_var_namespace] = new TPT::Object(const_default_namespace);
    }

    if ( (var_it = var_table.find(const_var_classname)) == var_end) {
	obj.hash()[const_var_classname] = new TPT::Object(const_default_classname);
    }

    if ( (var_it = var_table.find(const_var_source)) == var_end) {
	obj.hash()[const_var_source] = new TPT::Object(const_default_source);
    }

    std::string actual_header_name;

    if ( (var_it = var_table.find(const_var_header)) == var_end) {
	actual_header_name = const_default_header;
	obj.hash()[const_var_header] = new TPT::Object(actual_header_name);
    } else {
	actual_header_name = var_it->second;
    }

    if ( (var_it = var_table.find(const_var_header_def)) == var_end) {
	std::string::size_type i=0, size=actual_header_name.size();
	for (; i < size; ++i) if (!std::strchr(const_valid_cpp_chars, actual_header_name[i])) actual_header_name[i] = '_';
	obj.hash()[const_var_header_def] = new TPT::Object(actual_header_name);
    }

    if ( (var_it = var_table.find(const_var_include)) != var_end) {
	std::vector<std::string> include_files;
	cxxtools::split(var_it->second, std::string(","), include_files);
	std::for_each(include_files.begin(), include_files.end(), std::ptr_fun(cxxtools::normalize<std::string>));

	TPT::Object::PtrType include_file_names = new TPT::Object(TPT::Object::type_array);
	std::vector<std::string>::const_iterator it(include_files.begin()), end(include_files.end());
	for (; it!=end; ++it) include_file_names.get()->array().push_back(new TPT::Object(*it));

	obj.hash()[const_var_include_files] = include_file_names;
    }

    set_includes(aod, obj);
    gen_command_enum(application, obj);
    tpt_parser parser(obj);
    parser.parse(tptcode_header, sizeof(tptcode_header)-1, obj.hash()[const_var_header].get()->scalar().c_str());
    parser.parse(tptcode_source, sizeof(tptcode_source)-1, obj.hash()[const_var_source].get()->scalar().c_str());
}
//####################################################################

namespace {

//####################################################################
void process_default (const cloxx::option &op, std::vector<std::string> &init_list, TPT::Object &obj) {
    if (op.get_modifier() != cloxx::option::modifier_none) return;
    
    std::string default_value = op.get_default();
    if (op.get_type() == cloxx::option::type_string && default_value.empty()) return;

    switch (op.get_type()) {
	case cloxx::option::type_flag:
	case cloxx::option::type_bool:
	    if (default_value.empty()) default_value = "false";
	    break;
	case cloxx::option::type_enum:
	    if (default_value.empty()) default_value = op.get_enum_table().begin()->first;
	    default_value.insert(0, "_"); default_value.insert(0, op.get_id());
	    break;
	case cloxx::option::type_int:
	    if (default_value.empty()) default_value = "0";
	    break;
	case cloxx::option::type_double:
	    if (default_value.empty()) default_value = "0.0";
	    break;
	case cloxx::option::type_string:
	    cxxtools::quotemeta(default_value);
	    default_value.insert(0, "\"");
	    default_value += "\"";
	    break;
    }

    // add a cxx_default variable with the updated default value;
    obj.hash()["options"].get()->hash()[op.get_id()].get()->hash()["cxx_default"] = new TPT::Object(default_value);

    // add the default value for a constructor init list
    std::string tmp(op.get_id()); tmp += "("; tmp += default_value; tmp += ")";
    init_list.push_back(tmp);
}
//####################################################################
void process_includes (const cloxx::option &op, all_options_data &aod) {
    switch (op.get_modifier()) {
	case cloxx::option::modifier_none:
	    return;
	case cloxx::option::modifier_vector:
	    if (op.get_type() == cloxx::option::type_bool || op.get_type() == cloxx::option::type_flag) aod.include_list = true;
	    else aod.include_vector = true;
	    break;
	case cloxx::option::modifier_map:
	    aod.include_map = true;
	    break;
    }
}
//####################################################################
void set_default_list (std::vector<std::string> &dl, TPT::Object &obj) {
    if (!dl.empty()) {
	std::sort(dl.begin(), dl.end(), compare_default());

	std::string tmp = ":\n\t    ";
	tmp += cxxtools::join(std::string(",\n\t    "), dl.begin(), dl.end());
	tmp += "\n\t";

	obj.hash()["struct_init_list"] = new TPT::Object(tmp);
    }
}
//####################################################################
void set_includes (all_options_data &aod, TPT::Object &obj) {
    if (aod.include_list)   obj.hash()["include_list"] = new TPT::Object("yes");
    if (aod.include_vector) obj.hash()["include_vector"] = new TPT::Object("yes");
    if (aod.include_map)    obj.hash()["include_map"] = new TPT::Object("yes");
}
//####################################################################
void gen_command_enum (const cloxx::app &application, TPT::Object &obj) {
    const std::list<cloxx::command> &commands = application.get_commands();
    std::list<cloxx::command>::const_iterator cmd_it(commands.begin()), cmd_end(commands.end());
    std::vector<std::string> command_enum;

    for (; cmd_it != cmd_end; ++cmd_it) {
	std::string member("command_");
	member += cmd_it->get_id();
	command_enum.push_back(member);
    }

    if (!command_enum.empty()) {
	obj.hash()["commands_enum"] = new TPT::Object(cxxtools::join(
		    std::string(",\n\t    "), command_enum.begin(), command_enum.end()));
    }
}
//####################################################################
void process_option_enum (const cloxx::option &op, std::vector<std::string> &member_list) {
    std::string member("option_"); member += op.get_id();
    member_list.push_back(member);
}
//####################################################################
void set_option_enum (const std::vector<std::string> &member_list, TPT::Object &obj) {
    if (!member_list.empty()) {
	obj.hash()["options_enum"] = new TPT::Object(cxxtools::join(
		    std::string(",\n\t\t"), member_list.begin(), member_list.end()));
    }
}
//####################################################################
void process_option_size (const cloxx::option &op, all_options_data &aod) {
    const std::list<std::string> &names = op.get_names();
    std::list<std::string>::const_iterator names_it(names.begin()), names_end(names.end());

    for (; names_it != names_end; ++names_it) {
	if (names_it->size() == 1) aod.short_options[*names_it] = new TPT::Object (op.get_id());
	else aod.long_options[*names_it] = new TPT::Object(op.get_id());
    }
}
//####################################################################
void process_option_enum (const cloxx::option &op, TPT::Object &obj) {
    if (op.get_type() != cloxx::option::type_enum) return;

    std::vector<std::string> enum_list;
    const cloxx::option::enum_table &et = op.get_enum_table();
    cloxx::option::enum_table::const_iterator et_it(et.begin()), et_end(et.end());

    for (; et_it != et_end; ++et_it) {
	std::string id(op.get_id()); id += "_"; id += et_it->first;
	enum_list.push_back(id);
    }

    obj.hash()["options"].get()->hash()[op.get_id()].get()->hash()["enum_members"]
	= new TPT::Object(cxxtools::join(std::string(",\n\t"), enum_list.begin(), enum_list.end()));
}
//####################################################################
void set_group_id (const cloxx::group &grp, TPT::Object &obj) {
    TPT::Object::PtrType group_id = new TPT::Object(grp.get_id());
    const std::list<cloxx::option> &options = grp.get_options();
    std::list<cloxx::option>::const_iterator op_it(options.begin()), op_end(options.end());
    for (; op_it != op_end; ++op_it) {
	obj.hash()["options"].get()->hash()[op_it->get_id()].get()->hash()["group_id"] = group_id;
    }
}

} // end anonymous namespace
