/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::generator_man class.
**/

// cloxx includes
#include "generator_man.h"
#include "common.h"
#include "tpthelper.h"
#include <cloxx/app.h>
#include <cloxx/config.h>
#include <cloxx/option.h>

// libtpt includes
#include <libtpt/symbols.h>
#include <libtpt/buffer.h>
#include <libtpt/parse.h>
#include <libtpt/object.h>

// standard includes
#include <ctime>
#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>

// include template
#include "template_man.h"

//####################################################################
namespace {
    const char const_var_manpage[]	= "man_file";
    const char const_var_mansection[]	= "man_section";
    const char const_var_mandate[]	= "man_date";

    const char const_cb_rmargname[]	= "cloxx_rmargname";
    const char const_cb_manescape[]	= "cloxx_manescape";
    const char const_man_chars[]	= "-'`.\\";

    const char *const_months[]		= {
	"January", "February", "March", "April", "May", "June",
	"July", "August", "September", "October", "November", "December"
    };

    bool tptcb_rmargname (std::ostream &s, TPT::Object &params);
    bool tptcb_manescape (std::ostream &s, TPT::Object &params);
}
//####################################################################
void cloxx::generator_man::generate (const app &application, TPT::Object &obj) {
    const config::variable_table &vt = application.get_config().get_variables();
    config::variable_table::const_iterator var;
    std::string manpage_filename(application.get_name()), manpage_section("1"), manpage_date;
    manpage_filename += ".1";

    if ( (var = vt.find(const_var_manpage)) != vt.end()) manpage_filename = var->second;
    if ( (var = vt.find(const_var_mansection)) != vt.end()) manpage_section = var->second;
    if ( (var = vt.find(const_var_mandate)) != vt.end()) manpage_date = var->second;

    if (manpage_date.empty()) {
	std::time_t today = std::time(0);
	std::tm *today_tm = std::localtime(&today);
	if (!today_tm) throw std::runtime_error("ouch, std::localtime returned zero");

	std::ostringstream datestring;
	datestring << const_months[today_tm->tm_mon] << " ";
	datestring << today_tm->tm_mday << ", ";
	datestring << today_tm->tm_year + 1900;

	manpage_date = datestring.str();
    }

    obj.hash()[const_var_manpage]	= new TPT::Object(manpage_filename);
    obj.hash()[const_var_mansection]	= new TPT::Object(manpage_section);
    obj.hash()[const_var_mandate]	= new TPT::Object(manpage_date);

    std::ofstream file_stream(manpage_filename.c_str());
    if (!file_stream) {
	std::string error("unable to create manpage '"); error += manpage_filename; error += "'";
	throw std::runtime_error(error);
    }

    TPT::Symbols symtable; symtable.set(const_tpt_varname, obj);
    TPT::Buffer buffer(tptcode, sizeof(tptcode)-1);
    TPT::Parser parser(buffer, symtable);

    parser.addfunction(const_cb_rmargname, &tptcb_rmargname);
    parser.addfunction(const_cb_manescape, &tptcb_manescape);

    if (parser.run(file_stream)) {
	TPT::ErrorList errors;
	parser.geterrorlist(errors);

	std::cerr << "there is an error in the manpage template file\n";
	std::ostream_iterator<std::string> error_stream(std::cerr, "\n");
	std::copy(errors.begin(), errors.end(), error_stream);
	std::cerr << std::endl;
    }
}
//####################################################################

namespace {

//####################################################################
bool tptcb_rmargname (std::ostream &s, TPT::Object &params) {
    if (params.array().size() != 1) return true;

    std::string signature = params.array()[0].get()->scalar();
    std::string::size_type pos(signature.size() - 1);

    while (pos != 0 && signature[pos] != ' ') --pos;
    if (pos == 0) return true;

    signature.erase(pos);
    s << signature;
    return false; // false is good in TPT
}
//####################################################################
bool tptcb_manescape (std::ostream &s, TPT::Object &params) {
    TPT::Object::ArrayType::const_iterator pi(params.array().begin()), pend(params.array().end());

    for (; pi != pend; ++pi) {
	if (pi->get()->gettype() != TPT::Object::type_scalar) return true;

	std::string data = pi->get()->scalar();
	std::string::size_type pos(0), size(data.size());

	while (pos < size) {
	    if (std::strchr(const_man_chars, data[pos])) {
		data.insert(pos++, "\\");
		size = data.size();
	    }

	    ++pos;
	}

	s << data;
    }

    return false; // false is good in TPT
}

} // end anonymous namespace
