/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::genfactory class.
**/

// cloxx includes
#include <cloxx/genfactory.h>
#include <cloxx/generator.h>

/*
 * Concrete Generators
 */
#include "generator_cxx.h"
#include "generator_xml.h"
#include "generator_template.h"
#include "generator_man.h"

// standard includes
#include <vector>
#include <map>
#include <string>

//####################################################################
class cloxx::genfactory::pimpl {
public:
    typedef std::map<std::string, generator*> gentbl;
    mutable gentbl generators_;

    ~pimpl (void) {
	gentbl::const_iterator i(generators_.begin()), end(generators_.end());
	for (; i != end; ++i) delete i->second;
    }
};
//####################################################################
cloxx::genfactory::genfactory (void) {
    pimpl_ = new pimpl;
}
//####################################################################
cloxx::genfactory::~genfactory (void) {
    delete pimpl_;
}
//####################################################################
const std::vector<const char*> cloxx::genfactory::list_generators (void) const {
    std::vector<const char*> gen_list;

    gen_list.push_back("cxx");
    gen_list.push_back("xml");
    gen_list.push_back("template");
    gen_list.push_back("man");

    return gen_list;
}
//####################################################################
cloxx::generator* cloxx::genfactory::get_generator (const char *name) const {
    pimpl::gentbl::const_iterator gi = pimpl_->generators_.find(name);
    if (gi != pimpl_->generators_.end()) return gi->second;

    generator* cgen = 0; // concret generator

    if (std::strcmp(name, "cxx") == 0) {
	cgen = new generator_cxx;
    } else if (std::strcmp(name, "xml") == 0) {
	cgen = new generator_xml;
    } else if (std::strcmp(name, "template") == 0) {
	cgen = new generator_template;
    } else if (std::strcmp(name, "man") == 0) {
	cgen = new generator_man;
    }

    if (!cgen) return 0;
    pimpl_->generators_[name] = cgen;
    return cgen;
}
