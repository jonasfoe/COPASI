/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

// cloxx includes
#include <cloxx/option.h>
#include "common.h"

// xmlwrapp includes
#include <xmlwrapp/xmlwrapp.h>

// cxxtools includes
#include <cxxtools/strutil.h>

// standard includes
#include <list>
#include <memory>
#include <string>
#include <cstring>
#include <stdexcept>
#include <algorithm>

//####################################################################
namespace {
    const char const_attr_default[]	= "default";
    const char const_attr_modifier[]	= "modifier";
    const char const_attr_location[]	= "location";
    const char const_attr_hidden[]	= "hidden";
    const char const_attr_argname[]	= "argname";
    const char const_attr_autothrow[]	= "autothrow";

    const char const_type_flag[]	= "flag";
    const char const_type_bool[]	= "bool";
    const char const_type_enum[]	= "enum";
    const char const_type_int[]		= "int";
    const char const_type_double[]	= "double";
    const char const_type_string[]	= "string";

    const char const_modifier_vector[]	= "vector";
    const char const_modifier_map[]	= "map";
    const char const_modifier_none[]	= "none";

    const char const_location_cl[]	= "commandline";
    const char const_location_cf[]	= "configfile";
    const char const_location_both[]	= "both";

    const char const_tag_enum[]		= "enum";
    const char const_enum_id[]		= "id";
    const char const_enum_name[]	= "name";

    const char const_tag_range[]	= "range";
    const char const_range_min[]	= "min";
    const char const_range_max[]	= "max";
}   
//####################################################################
class cloxx::option::pimpl {
public:
    pimpl (void)
	: type_(type_flag), modifier_(modifier_none),
	  location_(location_both), mandatory_(false), hidden_(false), strict_(false)
    { }

    void import_from_xml (const xml::node &n);
    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;

    void set_id (const char *id);
    void set_default (const char *d);
    void set_comment (const char *comment);
    const char* get_argname (void) const;
    const char* get_signature (void) const;

    void set_type (option::types type)				{ type_ = type;			    }
    void set_modifier (option::modifiers modifier)		{ modifier_ = modifier;		    }
    void set_location (option::locations location)		{ location_ = location;		    }
    void set_hidden (bool hidden)				{ hidden_ = hidden;		    }
    void set_mandatory (bool mandatory)				{ mandatory_ = mandatory;	    }
    void set_names (const std::list<std::string> &names)	{ names_ = names;		    }
    void set_enum_table (const option::enum_table &enums)	{ enum_table_ = enums;		    }
    void set_argname (const char *argname)			{ argname_ = argname;		    }
    void set_range_min (const char *range_min)			{ range_min_ = range_min;	    }
    void set_range_max (const char *range_max)			{ range_max_ = range_max;	    }
    void set_description (const std::list<std::string> &paras)	{ desc_paras_ = paras;		    }
    void set_autothrow_id (const char *id)			{ autothrow_ = id;		    }
    void set_strict (bool strict)				{ strict_ = strict;		    }

    const char* get_id (void) const				{ return id_.c_str();		    }
    option::types get_type (void) const				{ return type_;			    }
    option::modifiers get_modifier (void) const			{ return modifier_;		    }
    option::locations get_location (void) const			{ return location_;		    }
    bool get_hidden (void) const				{ return hidden_;		    }
    bool get_mandatory (void) const				{ return mandatory_;		    }
    const char* get_default (void) const			{ return default_.c_str();	    }
    const char* get_comment (void) const			{ return comment_.c_str();	    }
    const std::list<std::string>& get_names (void) const	{ return names_;		    }
    const option::enum_table& get_enum_table (void) const	{ return enum_table_;		    }
    const char* get_range_min (void) const			{ return range_min_.c_str();	    }
    const char* get_range_max (void) const			{ return range_max_.c_str();	    }
    const std::list<std::string>& get_description (void) const	{ return desc_paras_;		    }
    const char* get_autothrow_id (void) const			{ return autothrow_.c_str();	    }
    bool get_strict (void) const				{ return strict_;		    }
private:
    std::string id_;
    option::types type_;
    option::modifiers modifier_;
    option::locations location_;
    bool mandatory_;
    bool hidden_;
    bool strict_;
    std::string default_;
    std::string comment_;
    std::string argname_;
    std::string range_min_;
    std::string range_max_;
    std::string autothrow_;
    std::list<std::string> names_;
    option::enum_table enum_table_;
    std::list<std::string> desc_paras_;
    mutable std::string signature_;

    void set_type_from_string (const char *type);
    void set_modifier_from_string (const char *modifier);
    void set_location_from_string (const char *location);
    void set_hidden_from_string (const char *hidden);
    void set_strict_from_string (const char *strict);
    void set_mandatory_from_string (const char *mandatory);
    void add_name (const char *name);

    const char* get_type_as_string (void) const;
    const char* get_modifier_as_string (void) const;
    const char* get_location_as_string (void) const;
    const char* get_hidden_as_string (void) const;
    const char* get_strict_as_string (void) const;
    const char* get_mandatory_as_string (void) const;
};
//####################################################################
cloxx::option::option (const xml::node &n) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->import_from_xml(n);
    ap.release();
}
//####################################################################
cloxx::option::option (const char *id) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->set_id(id);
    ap.release();
}
//####################################################################
cloxx::option::option (const option &other) {
    pimpl_ = new pimpl(*(other.pimpl_));
}
//####################################################################
cloxx::option& cloxx::option::operator= (const option &other) {
    option tmp(other);
    swap(tmp);
    return *this;
}
//####################################################################
void cloxx::option::swap (option &other) {
    std::swap(pimpl_, other.pimpl_);
}
//####################################################################
cloxx::option::~option (void) {
    delete pimpl_;
}
//####################################################################
/*
 * Bridge Functions
 */
void cloxx::option::export_to_xml (xml::node &n) const			    { pimpl_->export_to_xml(n);		}
void cloxx::option::export_to_tpt (TPT::Object &o) const		    { pimpl_->export_to_tpt(o);		}
void cloxx::option::set_id (const char *id)				    { pimpl_->set_id(id);		}
void cloxx::option::set_type (types t)					    { pimpl_->set_type(t);		}
void cloxx::option::set_modifier (modifiers m)				    { pimpl_->set_modifier(m);		}
void cloxx::option::set_mandatory (bool mandatory)			    { pimpl_->set_mandatory(mandatory); }
void cloxx::option::set_names (const std::list<std::string> &names)	    { pimpl_->set_names(names);		}
void cloxx::option::set_default (const char *d)				    { pimpl_->set_default(d);		}
void cloxx::option::set_hidden (bool hidden)				    { pimpl_->set_hidden(hidden);	}
void cloxx::option::set_enum_table (const enum_table &enums)		    { pimpl_->set_enum_table(enums);	}
void cloxx::option::set_argname (const char *argname)			    { pimpl_->set_argname(argname);	}
void cloxx::option::set_range_min (const char *range_min)		    { pimpl_->set_range_min(range_min);	}
void cloxx::option::set_range_max (const char *range_max)		    { pimpl_->set_range_max(range_max);	}
void cloxx::option::set_description (const std::list<std::string> &paras)   { pimpl_->set_description(paras);	}
void cloxx::option::set_comment (const char *comment)			    { pimpl_->set_comment(comment);	}
void cloxx::option::set_autothrow_id (const char *id)			    { pimpl_->set_autothrow_id(id);	}
void cloxx::option::set_strict (bool strict)				    { pimpl_->set_strict(strict);	}

const char* cloxx::option::get_id (void) const				    { return pimpl_->get_id();		}
cloxx::option::types cloxx::option::get_type (void) const		    { return pimpl_->get_type();	}
cloxx::option::modifiers cloxx::option::get_modifier (void) const	    { return pimpl_->get_modifier();	}
bool cloxx::option::get_mandatory (void) const				    { return pimpl_->get_mandatory();	}
const std::list<std::string>& cloxx::option::get_names (void) const	    { return pimpl_->get_names();	}
const char* cloxx::option::get_default (void) const			    { return pimpl_->get_default();	}
bool cloxx::option::get_hidden (void) const				    { return pimpl_->get_hidden();	}
const cloxx::option::enum_table& cloxx::option::get_enum_table (void) const { return pimpl_->get_enum_table();	}
const std::list<std::string>& cloxx::option::get_description (void) const   { return pimpl_->get_description(); }
const char* cloxx::option::get_comment (void) const			    { return pimpl_->get_comment();	}
const char* cloxx::option::get_autothrow_id (void) const		    { return pimpl_->get_autothrow_id();}
const char* cloxx::option::get_signature (void) const			    { return pimpl_->get_signature();	}
bool cloxx::option::get_strict (void) const				    { return pimpl_->get_strict();	}
//####################################################################
void cloxx::option::pimpl::import_from_xml (const xml::node &n) {
    xml::attributes::const_iterator id_it(n.get_attributes().find(const_attr_id));
    set_id(id_it == n.get_attributes().end() ? 0 : id_it->get_value());

    xml::attributes::const_iterator type_id(n.get_attributes().find(const_attr_type));
    set_type_from_string(type_id == n.get_attributes().end() ? 0 : type_id->get_value());

    xml::attributes::const_iterator default_it(n.get_attributes().find(const_attr_default));
    if (default_it != n.get_attributes().end()) set_default(default_it->get_value());

    xml::attributes::const_iterator mandatory_it(n.get_attributes().find(const_attr_mandatory));
    if (mandatory_it != n.get_attributes().end()) set_mandatory_from_string(mandatory_it->get_value());

    xml::attributes::const_iterator location_it(n.get_attributes().find(const_attr_location));
    if (location_it != n.get_attributes().end()) set_location_from_string(location_it->get_value());

    xml::attributes::const_iterator hidden_it(n.get_attributes().find(const_attr_hidden));
    if (hidden_it != n.get_attributes().end()) set_hidden_from_string(hidden_it->get_value());
    
    xml::attributes::const_iterator strict_it(n.get_attributes().find(const_attr_strict));
    if (strict_it != n.get_attributes().end()) set_strict_from_string(strict_it->get_value());

    xml::attributes::const_iterator modifier_it(n.get_attributes().find(const_attr_modifier));
    if (modifier_it != n.get_attributes().end()) set_modifier_from_string(modifier_it->get_value());

    xml::attributes::const_iterator argname_it(n.get_attributes().find(const_attr_argname));
    if (argname_it != n.get_attributes().end()) set_argname(argname_it->get_value());
    
    xml::attributes::const_iterator autothrow_it(n.get_attributes().find(const_attr_autothrow));
    if (autothrow_it != n.get_attributes().end()) set_autothrow_id(autothrow_it->get_value());

    xml::node::const_iterator i(n.begin()), end(n.end());
    for (; i != end; ++i) {
	if (std::strcmp(i->get_name(), const_tag_name) == 0) {
	    add_name(i->get_content());
	} else if (std::strcmp(i->get_name(), const_tag_comment) == 0) {
	    set_comment(i->get_content());
	} else if (std::strcmp(i->get_name(), const_tag_enum) == 0) {
	    std::string key, value;

	    xml::attributes::const_iterator id_it(i->get_attributes().find(const_enum_id));
	    if (id_it != i->get_attributes().end()) key = id_it->get_value();

	    xml::attributes::const_iterator name_it(i->get_attributes().find(const_enum_name));
	    if (name_it != i->get_attributes().end()) value = name_it->get_value();

	    if (key.empty() || value.empty()) {
		std::string error("option '"); error += id_; error += "' missing enum/@id or enum/@name";
		throw std::runtime_error(error);
	    }

	    enum_table_[key] = value;
	} else if (std::strcmp(i->get_name(), const_tag_range) == 0) {
	    std::string range_min, range_max;

	    xml::attributes::const_iterator min_it(i->get_attributes().find(const_range_min));
	    if (min_it != i->get_attributes().end()) range_min = min_it->get_value();

	    xml::attributes::const_iterator max_it(i->get_attributes().find(const_range_max));
	    if (max_it != i->get_attributes().end()) range_max = max_it->get_value();

	    if (range_min.empty() && range_max.empty()) {
		std::string error("option '"); error += id_; error += "' missing range/@min or range/@max";
		throw std::runtime_error(error);
	    }

	    if (!range_min.empty()) set_range_min(range_min.c_str());
	    if (!range_max.empty()) set_range_max(range_max.c_str());
	} else if (std::strcmp(i->get_name(), const_tag_description) == 0) {
	    import_description(*i, desc_paras_);
	}
    }

    if (names_.empty()) {
	std::string error("option '"); error += id_; error += "' does not have any names";
	throw std::runtime_error(error);
    }

    if (type_ == option::type_enum && enum_table_.empty()) {
	std::string error("option '"); error += id_; error += "' is of type enum but does not have any enum tags";
	throw std::runtime_error(error);
    }

    if ((!range_min_.empty() || !range_max_.empty()) && (type_ != option::type_int && type_ != option::type_double)) {
	std::string error("option '"); error += id_; error += "' has range set but is not int or double type";
	throw std::runtime_error(error);
    }

    if (!autothrow_.empty() && type_ != type_flag) {
	std::string error("option '"); error += id_; error += "' has an autothrow id but is not of type flag";
	throw std::runtime_error(error);
    }

    if (type_ == option::type_flag && modifier_ != option::modifier_none) {
	std::string error("option '"); error += id_; error += "' has a type of 'flag' but is using a modifier";
	throw std::runtime_error(error);
    }
}
//####################################################################
void cloxx::option::pimpl::export_to_xml (xml::node &n) const {
    n.get_attributes().insert(const_attr_id, id_.c_str());
    n.get_attributes().insert(const_attr_type, get_type_as_string());
    n.get_attributes().insert(const_attr_modifier, get_modifier_as_string());
    n.get_attributes().insert(const_attr_mandatory, get_mandatory_as_string());
    n.get_attributes().insert(const_attr_location, get_location_as_string());
    n.get_attributes().insert(const_attr_hidden, get_hidden_as_string());
    n.get_attributes().insert(const_attr_strict, get_strict_as_string());

    if (!autothrow_.empty()) n.get_attributes().insert(const_attr_autothrow, autothrow_.c_str());
    if (!default_.empty())   n.get_attributes().insert(const_attr_default, default_.c_str());
    if (!argname_.empty())   n.get_attributes().insert(const_attr_argname, argname_.c_str());

    std::list<std::string>::const_iterator i(names_.begin()), end(names_.end());
    for (; i != end; ++i) n.push_back(xml::node(const_tag_name, i->c_str()));

    if (!range_min_.empty() || !range_max_.empty()) {
	xml::node range_node(const_tag_range);
	if (!range_min_.empty()) range_node.get_attributes().insert(const_range_min, range_min_.c_str());
	if (!range_max_.empty()) range_node.get_attributes().insert(const_range_max, range_max_.c_str());
	n.push_back(range_node);
    }

    option::enum_table::const_iterator enums_it(enum_table_.begin()), enums_end(enum_table_.end());
    for (; enums_it != enums_end; ++enums_it) {
	xml::node enum_node(const_tag_enum);
	enum_node.get_attributes().insert(const_enum_id, enums_it->first.c_str());
	enum_node.get_attributes().insert(const_enum_name, enums_it->second.c_str());
	n.push_back(enum_node);
    }

    if (!comment_.empty()) n.push_back(xml::node(const_tag_comment, comment_.c_str()));
    export_description(n, desc_paras_);
}
//####################################################################
void cloxx::option::pimpl::export_to_tpt (TPT::Object &o) const {
    TPT::Object::PtrType option_data = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::HashType &data_hash = option_data.get()->hash();

    data_hash[const_attr_id]	    = new TPT::Object(id_);
    data_hash[const_attr_type]	    = new TPT::Object(get_type_as_string());
    data_hash[const_attr_modifier]  = new TPT::Object(get_modifier_as_string());
    data_hash[const_attr_mandatory] = new TPT::Object(get_mandatory_as_string());
    data_hash[const_attr_location]  = new TPT::Object(get_location_as_string());
    data_hash[const_attr_hidden]    = new TPT::Object(get_hidden_as_string());
    data_hash[const_attr_strict]    = new TPT::Object(get_strict_as_string());
    data_hash["signature"]	    = new TPT::Object(get_signature());

    TPT::Object::PtrType names_array = new TPT::Object(TPT::Object::type_array);
    std::list<std::string>::const_iterator names_it(names_.begin()), names_end(names_.end());
    for (; names_it != names_end; ++names_it) names_array.get()->array().push_back(new TPT::Object(*names_it));
    data_hash["names"] = names_array;
    
    TPT::Object::PtrType enum_hash = new TPT::Object(TPT::Object::type_hash);
    option::enum_table::const_iterator enums_it(enum_table_.begin()), enums_end(enum_table_.end());
    for (; enums_it != enums_end; ++enums_it) enum_hash.get()->hash()[enums_it->first] = new TPT::Object(enums_it->second);
    data_hash["enums"] = enum_hash;

    if (!autothrow_.empty())	data_hash[const_attr_autothrow] = new TPT::Object(autothrow_);
    if (!comment_.empty())	data_hash[const_tag_comment] = new TPT::Object(comment_);
    if (!default_.empty())	data_hash[const_attr_default] = new TPT::Object(default_);
    if (!argname_.empty())	data_hash[const_attr_argname] = new TPT::Object(argname_);
    if (!range_min_.empty())	data_hash["range_min"] = new TPT::Object(range_min_);
    if (!range_max_.empty())	data_hash["range_max"] = new TPT::Object(range_max_);

    export_description(*(option_data.get()), desc_paras_);
    o.hash()["options"].get()->hash()[id_] = option_data;
}
//####################################################################
void cloxx::option::pimpl::set_id (const char *id) {
    if (!id) throw std::runtime_error("blank or missing option/@id");

    id_ = id;
    cxxtools::normalize(id_);

    if (id_.empty()) throw std::runtime_error("blank optioni/@id");
}
//####################################################################
void cloxx::option::pimpl::set_default (const char *d) {
    if (!d) throw std::runtime_error("blank or missing option/@default");

    default_ = d;
    cxxtools::normalize(default_);

    if (default_.empty()) throw std::runtime_error("blank option/@default");
}
//####################################################################
void cloxx::option::pimpl::set_comment (const char *comment) {
    if (!comment) throw std::runtime_error("blank or missing option/comment");

    comment_ = comment;
    cxxtools::normalize(comment_);

    if (comment_.empty()) throw std::runtime_error("blank option/comment");
}
//####################################################################
const char* cloxx::option::pimpl::get_argname (void) const {
    if (!argname_.empty()) return argname_.c_str();
    return get_type_as_string();
}
//####################################################################
void cloxx::option::pimpl::set_type_from_string (const char *type) {
    if (!type) throw std::runtime_error("blank or missing option/@type");

    switch (*type) {
    case 'b':
	if (std::strcmp(type, const_type_bool) == 0) {
	    set_type(option::type_bool);
	    return;
	}
	break;
    case 'd':
	if (std::strcmp(type, const_type_double) == 0) {
	    set_type(option::type_double);
	    return;
	}
	break;
    case 'e':
	if (std::strcmp(type, const_type_enum) == 0) {
	    set_type(option::type_enum);
	    return;
	}
	break;
    case 'f':
	if (std::strcmp(type, const_type_flag) == 0) {
	    set_type(option::type_flag);
	    return;
	}
	break;
    case 'i':
	if (std::strcmp(type, const_type_int) == 0) {
	    set_type(option::type_int);
	    return;
	}
	break;
    case 's':
	if (std::strcmp(type, const_type_string) == 0) {
	    set_type(option::type_string);
	    return;
	}
	break;
    }

    std::string error("unknown option/@type '"); error += type; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::option::pimpl::set_modifier_from_string (const char *modifier) {
    if (!modifier) throw std::runtime_error("blank or missing option/@modifier");

    switch (*modifier) {
    case 'm':
	if (std::strcmp(modifier, const_modifier_map) == 0) {
	    set_modifier(option::modifier_map);
	    return;
	}
	break;
    case 'n':
	if (std::strcmp(modifier, const_modifier_none) == 0) {
	    set_modifier(option::modifier_none);
	    return;
	}
	break;
    case 'v':
	if (std::strcmp(modifier, const_modifier_vector) == 0) {
	    set_modifier(option::modifier_vector);
	    return;
	}
	break;
    }

    std::string error("unknown option/@modifier '"); error += modifier; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::option::pimpl::set_location_from_string (const char *location) {
    if (!location) throw std::runtime_error("blank or missing option/@location");

    switch (*location) {
    case 'b':
	if (std::strcmp(location, const_location_both) == 0) {
	    set_location(option::location_both);
	    return;
	}
	break;
    case 'c':
	if (std::strcmp(location, const_location_cl) == 0) {
	    set_location(option::location_command_line);
	    return;
	}
	if (std::strcmp(location, const_location_cf) == 0) {
	    set_location(option::location_config_file);
	    return;
	}
	break;
    }

    std::string error("unknown option/@location '"); error += location; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::option::pimpl::set_mandatory_from_string (const char *mandatory) {
    if (!mandatory) throw std::runtime_error("blank or missing option/@mandatory");
    if (set_bool_from_string(mandatory_, mandatory)) return;
    std::string error("unknown value for option/@mandatory '"); error += mandatory; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::option::pimpl::set_hidden_from_string (const char *hidden) {
    if (!hidden) throw std::runtime_error("blank or missing option/@hidden");
    if (set_bool_from_string(hidden_, hidden)) return;
    std::string error("unknown value for option/@hidden '"); error += hidden; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::option::pimpl::set_strict_from_string (const char *strict) {
    if (!strict) throw std::runtime_error("blank or missing option/@strict");
    if (set_bool_from_string(strict_, strict)) return;
    std::string error("unknown value for option/@strict '"); error += strict; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::option::pimpl::add_name (const char *name) {
    if (!name) throw std::runtime_error("blank or missing option/name");

    std::string sname = name;
    cxxtools::normalize(sname);

    if (sname.empty()) throw std::runtime_error("blank option/name");
    names_.push_back(sname);
}
//####################################################################
const char* cloxx::option::pimpl::get_type_as_string (void) const {
    switch (type_) {
	case option::type_flag:	    return const_type_flag;
	case option::type_bool:	    return const_type_bool;
	case option::type_enum:	    return const_type_enum;
	case option::type_int:	    return const_type_int;
	case option::type_double:   return const_type_double;
	case option::type_string:   return const_type_string;
    }

    return 0; // kill compiler warning
}
//####################################################################
const char* cloxx::option::pimpl::get_modifier_as_string (void) const {
    switch (modifier_) {
	case option::modifier_none:	return const_modifier_none;
	case option::modifier_vector:	return const_modifier_vector;
	case option::modifier_map:	return const_modifier_map;
    }

    return 0; // kill compiler warning
}
//####################################################################
const char* cloxx::option::pimpl::get_location_as_string (void) const {
    switch (location_) {
	case option::location_command_line:	return const_location_cl;
	case option::location_config_file:	return const_location_cf;
	case option::location_both:		return const_location_both;
    }

    return 0; // kill compiler warning
}
//####################################################################
const char* cloxx::option::pimpl::get_mandatory_as_string (void) const {
    return get_string_from_bool(mandatory_);
}
//####################################################################
const char* cloxx::option::pimpl::get_hidden_as_string (void) const {
    return get_string_from_bool(hidden_);
}
//####################################################################
const char* cloxx::option::pimpl::get_strict_as_string (void) const {
    return get_string_from_bool(strict_);
}
//####################################################################
const char* cloxx::option::pimpl::get_signature (void) const {
    generate_signature(names_, signature_);
	
    if (type_ != type_flag) {
	signature_ += " "; signature_ += get_argname();
    }

    return signature_.c_str();
}
