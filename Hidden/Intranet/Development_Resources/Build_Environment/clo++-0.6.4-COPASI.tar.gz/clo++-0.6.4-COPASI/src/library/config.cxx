/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::config class.
**/

// cloxx includes
#include <cloxx/config.h>
#include "common.h"

// xmlwrapp includes
#include <xmlwrapp/xmlwrapp.h>

// libtpt includes
#include <libtpt/object.h>

// cxxtools includes
#include <cxxtools/strutil.h>

// standard includes
#include <list>
#include <memory>
#include <string>
#include <cstring>
#include <stdexcept>
#include <algorithm>

//####################################################################
namespace {
    const char const_tag_autohelp[]	    = "autohelp";

    const char const_tag_variable[]	    = "variable";
    const char const_variable_name[]	    = "name";
    const char const_variable_value[]	    = "value";

    const char const_tag_true[]		    = "true";
    const char const_tag_false[]	    = "false";

    const char const_attr_oporder[]	    = "oporder";
    const char const_oporder_posix[]	    = "posix";
    const char const_oporder_gnu[]	    = "gnu";

    const char const_attr_abbreviation[]    = "abbreviation";
    const char const_abbreviation_none[]    = "none";
    const char const_abbreviation_gnu[]	    = "gnu";

    const char const_attr_command[]	    = "command";
    const char const_command_optional[]	    = "optional";
    const char const_command_mandatory[]    = "mandatory";
}
//####################################################################
class cloxx::config::pimpl {
public:
    pimpl (void)
	: autohelp_state_(false), autohelp_id_("help"), oporder_(config::oporder_gnu),
	  abbreviation_(config::abbreviation_gnu), command_state_(config::command_optional)
    { }

    void import_from_xml (const xml::node &n);
    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;

    void set_autohelp_id (const char *id);
    const std::list<std::string>& get_autohelp_names (void) const;
    const std::list<std::string>& get_true_words (void) const;
    const std::list<std::string>& get_false_words (void) const;
    void append_variables (const config::variable_table &vt);
    
    void set_autohelp_state (bool state)				    { autohelp_state_ = state;		}
    void set_autohelp_names (const std::list<std::string> &names)	    { autohelp_names_ = names;		}
    void set_variable (const char *name, const char *value)		    { var_table_[name] = value;		}
    void set_true_words (const std::list<std::string> &true_words)	    { true_words_ = true_words;		}
    void set_false_words (const std::list<std::string> &false_words)	    { false_words_ = false_words;	}
    void set_oporder (config::oporder order)				    { oporder_ = order;			}
    void set_abbreviation (config::abbreviation ab)			    { abbreviation_ = ab;		}
    void set_command_state (config::command_state state)		    { command_state_ = state;		}

    bool get_autohelp_state (void) const				    { return autohelp_state_;		}
    const char* get_autohelp_id (void) const				    { return autohelp_id_.c_str();	}
    const config::variable_table& get_variables (void) const		    { return var_table_;		}
    config::oporder get_oporder (void) const				    { return oporder_;			}
    config::abbreviation get_abbreviation (void) const			    { return abbreviation_;		}
    config::command_state get_command_state (void) const		    { return command_state_;		}

    const char* get_autohelp_signature (void) const {
	const std::list<std::string> &names = get_autohelp_names();
	generate_signature(names, autohelp_sig_);
	return autohelp_sig_.c_str();
    }
private:
    bool autohelp_state_;
    std::string autohelp_id_;
    config::oporder oporder_;
    config::abbreviation abbreviation_;
    config::command_state command_state_;
    mutable std::list<std::string> true_words_;
    mutable std::list<std::string> false_words_;
    mutable std::list<std::string> autohelp_names_;
    mutable std::string autohelp_sig_;
    config::variable_table var_table_;

    void set_oporder_from_string (const char *order);
    void set_abbreviation_from_string (const char *ab);
    void set_command_state_from_string (const char *state);

    const char* get_oporder_as_string (void) const;
    const char* get_abbreviation_as_string (void) const;
    const char* get_command_state_as_string (void) const;
    
    void add_autohelp_name (const char *name);
    void add_true_word (const char *true_word);
    void add_false_word (const char *false_word);
};
//####################################################################
cloxx::config::config (void) {
    pimpl_ = new pimpl;
}
//####################################################################
cloxx::config::config (const xml::node &n) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->import_from_xml(n);
    ap.release();
}
//####################################################################
cloxx::config::config (const config &other) {
    pimpl_ = new pimpl(*(other.pimpl_));
}
//####################################################################
cloxx::config& cloxx::config::operator= (const config &other) {
    config tmp(other);
    swap(tmp);
    return *this;
}
//####################################################################
void cloxx::config::swap (config &other) {
    std::swap(pimpl_, other.pimpl_);
}
//####################################################################
cloxx::config::~config (void) {
    delete pimpl_;
}
//####################################################################

/*
 * Bridge Functions (from config to pimpl)
 */
void cloxx::config::import_from_xml (const xml::node &n)			    { pimpl_->import_from_xml(n);		}
void cloxx::config::export_to_xml (xml::node &n) const				    { pimpl_->export_to_xml(n);			}
void cloxx::config::export_to_tpt (TPT::Object &o) const			    { pimpl_->export_to_tpt(o);			}

void cloxx::config::set_autohelp_state (bool state)				    { pimpl_->set_autohelp_state(state);	}
void cloxx::config::set_autohelp_id (const char *id)				    { pimpl_->set_autohelp_id(id);		}
void cloxx::config::set_autohelp_names (const std::list<std::string> &names)	    { pimpl_->set_autohelp_names(names);	}
void cloxx::config::set_variable (const char *name, const char *value)		    { pimpl_->set_variable(name, value);	}
void cloxx::config::set_true_words (const std::list<std::string> &true_words)	    { pimpl_->set_true_words(true_words);	}
void cloxx::config::set_false_words (const std::list<std::string> &false_words)	    { pimpl_->set_false_words(false_words);	}
void cloxx::config::set_oporder (oporder order)					    { pimpl_->set_oporder(order);		}
void cloxx::config::set_abbreviation (abbreviation ab)				    { pimpl_->set_abbreviation(ab);		}
void cloxx::config::set_command_state (command_state state)			    { pimpl_->set_command_state(state);		}
void cloxx::config::append_variables (const variable_table &vt)			    { pimpl_->append_variables(vt);		}

bool cloxx::config::get_autohelp_state (void) const				    { return pimpl_->get_autohelp_state();	}
const char* cloxx::config::get_autohelp_id (void) const				    { return pimpl_->get_autohelp_id();		}
const std::list<std::string>& cloxx::config::get_autohelp_names (void) const	    { return pimpl_->get_autohelp_names();	}
const char* cloxx::config::get_autohelp_signature (void) const			    { return pimpl_->get_autohelp_signature();	}
const cloxx::config::variable_table& cloxx::config::get_variables (void) const	    { return pimpl_->get_variables();		}
const std::list<std::string>& cloxx::config::get_true_words (void) const	    { return pimpl_->get_true_words();		}
const std::list<std::string>& cloxx::config::get_false_words (void) const	    { return pimpl_->get_false_words();		}
cloxx::config::oporder cloxx::config::get_oporder (void) const			    { return pimpl_->get_oporder();		}
cloxx::config::abbreviation cloxx::config::get_abbreviation (void) const	    { return pimpl_->get_abbreviation();	}
cloxx::config::command_state cloxx::config::get_command_state (void) const	    { return pimpl_->get_command_state();	}

//####################################################################
void cloxx::config::pimpl::import_from_xml (const xml::node &n) {
    xml::attributes::const_iterator oporder_it(n.get_attributes().find(const_attr_oporder));
    if (oporder_it != n.get_attributes().end()) set_oporder_from_string(oporder_it->get_value());

    xml::attributes::const_iterator abb_it(n.get_attributes().find(const_attr_abbreviation));
    if (abb_it != n.get_attributes().end()) set_abbreviation_from_string(abb_it->get_value());

    xml::attributes::const_iterator state_it(n.get_attributes().find(const_attr_command));
    if (state_it != n.get_attributes().end()) set_command_state_from_string(state_it->get_value());

    xml::node::const_iterator node_it(n.begin()), node_end(n.end());
    for (; node_it != node_end; ++node_it) {
	if (std::strcmp(node_it->get_name(), const_tag_autohelp) == 0) {
	    xml::attributes::const_iterator help_id_it(node_it->get_attributes().find(const_attr_id));
	    if (help_id_it != node_it->get_attributes().end()) set_autohelp_id(help_id_it->get_value());

	    set_autohelp_state(true);

	    xml::node::const_iterator names_it(node_it->begin()), names_end(node_it->end());
	    for (; names_it != names_end; ++names_it) {
		if (std::strcmp(names_it->get_name(), const_tag_name) == 0) {
		    add_autohelp_name(names_it->get_content());
		}
	    }
	} else if (std::strcmp(node_it->get_name(), const_tag_true) == 0) {
	    add_true_word(node_it->get_content());
	} else if (std::strcmp(node_it->get_name(), const_tag_false) == 0) {
	    add_false_word(node_it->get_content());
	} else if (std::strcmp(node_it->get_name(), const_tag_variable) == 0) {
	    std::string name, value;

	    xml::attributes::const_iterator name_it(node_it->get_attributes().find(const_variable_name));
	    if (name_it != node_it->get_attributes().end()) name = name_it->get_value();

	    xml::attributes::const_iterator value_it(node_it->get_attributes().find(const_variable_value));
	    if (value_it != node_it->get_attributes().end()) value = value_it->get_value();

	    if (name.empty() || value.empty()) throw std::runtime_error("config/variable missing either @name or @value");
	    var_table_[name] = value;
	}
    }
}
//####################################################################
void cloxx::config::pimpl::export_to_xml (xml::node &n) const {
    n.get_attributes().insert(const_attr_oporder, get_oporder_as_string());
    n.get_attributes().insert(const_attr_abbreviation, get_abbreviation_as_string());
    n.get_attributes().insert(const_attr_command, get_command_state_as_string());

    if (autohelp_state_) {
	xml::node autohelp_node(const_tag_autohelp);
	autohelp_node.get_attributes().insert(const_attr_id, get_autohelp_id());

	const std::list<std::string> &names = get_autohelp_names();
	std::list<std::string>::const_iterator names_it(names.begin()), names_end(names.end());
	for (; names_it != names_end; ++names_it) autohelp_node.push_back(xml::node(const_tag_name, names_it->c_str()));
	
	n.push_back(autohelp_node);
    }

    variable_table::const_iterator var_it(var_table_.begin()), var_end(var_table_.end());
    for (; var_it != var_end; ++var_it) {
	xml::node varnode(const_tag_variable);
	varnode.get_attributes().insert(const_variable_name, var_it->first.c_str());
	varnode.get_attributes().insert(const_variable_value, var_it->second.c_str());
	n.push_back(varnode);
    }

    const std::list<std::string> &true_words = get_true_words();
    std::list<std::string>::const_iterator true_it(true_words.begin()), true_end(true_words.end());
    for (; true_it != true_end; ++true_it) n.push_back(xml::node(const_tag_true, true_it->c_str()));

    const std::list<std::string> &false_words = get_false_words();
    std::list<std::string>::const_iterator false_it(false_words.begin()), false_end(false_words.end());
    for (; false_it != false_end; ++false_it) n.push_back(xml::node(const_tag_false, false_it->c_str()));
}
//####################################################################
void cloxx::config::pimpl::export_to_tpt (TPT::Object &o) const {
    o.hash()[const_attr_oporder] = new TPT::Object(get_oporder_as_string());
    o.hash()[const_attr_abbreviation] = new TPT::Object(get_abbreviation_as_string());
    o.hash()[const_attr_command] = new TPT::Object(get_command_state_as_string());

    if (autohelp_state_) {
	TPT::Object::PtrType names_obj = new TPT::Object(TPT::Object::type_array);
	const std::list<std::string> &names = get_autohelp_names();
	std::list<std::string>::const_iterator names_it(names.begin()), names_end(names.end());
	for (; names_it != names_end; ++names_end) names_obj.get()->array().push_back(new TPT::Object(*names_it));
	o.hash()[const_tag_autohelp] = names_obj;
	o.hash()["help_signature"] = new TPT::Object(get_autohelp_signature());
	o.hash()["autohelp_id"] = new TPT::Object(get_autohelp_id());
    }

    variable_table::const_iterator var_it(var_table_.begin()), var_end(var_table_.end());
    for (; var_it != var_end; ++var_it) o.hash()[var_it->first] = new TPT::Object(var_it->second);

    const std::list<std::string> &true_words = get_true_words();
    std::list<std::string>::const_iterator true_it(true_words.begin()), true_end(true_words.end());
    TPT::Object::PtrType true_words_obj = new TPT::Object(TPT::Object::type_array);
    for (; true_it != true_end; ++true_it) true_words_obj.get()->array().push_back(new TPT::Object(*true_it));
    o.hash()["true_words"] = true_words_obj;

    const std::list<std::string> &false_words = get_false_words();
    std::list<std::string>::const_iterator false_it(false_words.begin()), false_end(false_words.end());
    TPT::Object::PtrType false_words_obj = new TPT::Object(TPT::Object::type_array);
    for (; false_it != false_end; ++false_it) false_words_obj.get()->array().push_back(new TPT::Object(*false_it));
    o.hash()["false_words"] = false_words_obj;
}
//####################################################################
const std::list<std::string>& cloxx::config::pimpl::get_autohelp_names (void) const {
    if (autohelp_names_.empty()) {
	autohelp_names_.push_back("h");
	autohelp_names_.push_back("?");
	autohelp_names_.push_back("help");
    }

    return autohelp_names_;
}
//####################################################################
const std::list<std::string>& cloxx::config::pimpl::get_true_words (void) const {
    if (true_words_.empty()) {
	true_words_.push_back("true");
	true_words_.push_back("yes");
    }

    return true_words_;
}
//####################################################################
const std::list<std::string>& cloxx::config::pimpl::get_false_words (void) const {
    if (false_words_.empty()) {
	false_words_.push_back("false");
	false_words_.push_back("no");
    }

    return false_words_;
}
//####################################################################
void cloxx::config::pimpl::set_oporder_from_string (const char *order) {
    if (!order) throw std::runtime_error("blank or missing config/@oporder");

    switch (*order) {

    case 'g':
	if (std::strcmp(order, const_oporder_gnu) == 0) {
	    set_oporder(oporder_gnu);
	    return;
	}
	break;
    
    case 'p':
	if (std::strcmp(order, const_oporder_posix) == 0) {
	    set_oporder(oporder_posix);
	    return;
	}
	break;

    }

    std::string error("unknown config/@oporder '"); error += order; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::config::pimpl::set_abbreviation_from_string (const char *ab) {
    if (!ab) throw std::runtime_error("blank or missing config/@abbreviation");

    switch (*ab) {

    case 'g':
	if (std::strcmp(ab, const_abbreviation_gnu) == 0) {
	    set_abbreviation(abbreviation_gnu);
	    return;
	}
	break;

    case 'n':
	if (std::strcmp(ab, const_abbreviation_none) == 0) {
	    set_abbreviation(abbreviation_none);
	    return;
	}
	break;

    }

    std::string error("unknown config/@abbreviation '"); error += ab; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
void cloxx::config::pimpl::set_command_state_from_string (const char *state) {
    if (!state) throw std::runtime_error("blank config/@command");

    switch (*state) {

    case 'm':
	if (std::strcmp(state, const_command_mandatory) == 0) {
	    set_command_state(command_mandatory);
	    return;
	}
	break;

    case 'o':
	if (std::strcmp(state, const_command_optional) == 0) {
	    set_command_state(command_optional);
	    return;
	}
	break;

    }

    std::string error("unknown config/@command '"); error += state; error += "'";
    throw std::runtime_error(error);
}
//####################################################################
const char* cloxx::config::pimpl::get_oporder_as_string (void) const {
    switch (oporder_) {
	case oporder_gnu:   return const_oporder_gnu;
	case oporder_posix: return const_oporder_posix;
    }

    return 0; // kill compiler warning
}
//####################################################################
const char* cloxx::config::pimpl::get_abbreviation_as_string (void) const {
    switch (abbreviation_) {
	case abbreviation_gnu:	return const_abbreviation_gnu;
	case abbreviation_none:	return const_abbreviation_none;
    }

    return 0; // kill compiler warning
}
//####################################################################
const char* cloxx::config::pimpl::get_command_state_as_string (void) const {
    switch (command_state_) {
	case command_mandatory:	return const_command_mandatory;
	case command_optional:	return const_command_optional;
    }

    return 0; // kill compiler warning
}
//####################################################################
void cloxx::config::pimpl::add_autohelp_name (const char *name) {
    std::string sname = name;
    cxxtools::normalize(sname);

    if (sname.empty()) throw std::runtime_error("blank config/autohelp/name content");
    autohelp_names_.push_back(sname);
}
//####################################################################
void cloxx::config::pimpl::add_true_word (const char *true_word) {
    std::string strue_word = true_word;
    cxxtools::normalize(strue_word);

    if (strue_word.empty()) throw std::runtime_error("blank config/true content");
    true_words_.push_back(strue_word);
}
//####################################################################
void cloxx::config::pimpl::add_false_word (const char *false_word) {
    std::string sfalse_word = false_word;
    cxxtools::normalize(sfalse_word);

    if (sfalse_word.empty()) throw std::runtime_error("blank config/false content");
    false_words_.push_back(sfalse_word);
}
//####################################################################
void cloxx::config::pimpl::set_autohelp_id (const char *id) {
    autohelp_id_ = id; cxxtools::normalize(autohelp_id_);
}
//####################################################################
void cloxx::config::pimpl::append_variables (const config::variable_table &vt) {
    config::variable_table::const_iterator vi(vt.begin()), vend(vt.end());
    for (; vi != vend; ++vi) var_table_[vi->first] = vi->second;
}
