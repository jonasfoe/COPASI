/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains code for helping out with libtpt
**/

#ifndef __cloxx_tpthelper_h__
#define __cloxx_tpthelper_h__

// libtpt includes
#include <libtpt/symbols.h>
#include <libtpt/buffer.h>
#include <libtpt/parse.h>
#include <libtpt/object.h>

// standard includes
#include <iterator>
#include <iostream>
#include <fstream>
#include <algorithm>

namespace {
    const char const_tpt_varname[]		= "cloxx";

    //####################################################################
    /*
     * The tpt_parser class is a small wrapper around the libtpt parser
     * class. This just makes things a little easier.
     */
    //####################################################################
    class tpt_parser {
    public:
	tpt_parser (TPT::Object &obj)
	{ symtable_.set(const_tpt_varname, obj); }

	void parse (const char *data, std::size_t size, const char *filename) {
	    std::ofstream stream(filename);
	    if (!stream) {
		std::string error("error opening output file '"); error += filename; error += "'";
		throw std::runtime_error(error);
	    }
		
	    TPT::Buffer buffer(data, size);
	    TPT::Parser parser(buffer, symtable_);

	    if (parser.run(stream)) {
		TPT::ErrorList errors;
		parser.geterrorlist(errors);

		std::cerr << "Ouch! there is an error in the teplate that generates '" << filename << "'\n";
		std::ostream_iterator<std::string> error_stream(std::cerr, "\n");
		std::copy(errors.begin(), errors.end(), error_stream);
		std::cerr << std::endl;
	    }
	}
    private:
	TPT::Symbols symtable_;
    };
    //####################################################################
}

#endif
