#! /bin/sh

CONVERT="perl ../../contrib/libtpt*/tools/tpt2c++.pl"
$CONVERT -v tptcode_header cxx_header.tpt > ../template_cxx_header.h
$CONVERT -v tptcode_source cxx_source.tpt > ../template_cxx_source.h
$CONVERT -v tptcode        manpage.tpt    > ../template_man.h
