/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::command class.
**/

// cloxx includes
#include <cloxx/command.h>
#include <cloxx/group.h>
#include <cloxx/option.h>
#include "common.h"

// xmlwrapp includes
#include <xmlwrapp/xmlwrapp.h>

// cxxtools includes
#include <cxxtools/strutil.h>

// standard includes
#include <set>
#include <list>
#include <memory>
#include <string>
#include <cstring>
#include <algorithm>
#include <stdexcept>

//####################################################################
namespace {
    struct uniq_name_check {
	uniq_name_check (const char *id, std::set<std::string> &s)
	    : id_(id), set_(s) { }

	void operator() (const cloxx::option &op) {
	    const std::list<std::string> &names = op.get_names();
	    std::list<std::string>::const_iterator names_i(names.begin()), names_end(names.end());

	    for (; names_i != names_end; ++names_i) {
		std::pair<std::set<std::string>::iterator, bool> status = set_.insert(*names_i);
		if (!status.second) {
		    std::string error("duplicate option name '"); error += *names_i; 
		    error += "' within command '"; error += id_; error += "'";
		    throw std::runtime_error(error);
		}
	    }
	}

	const char *id_;
	std::set<std::string> &set_;
    };
}
//####################################################################
class cloxx::command::pimpl {
public:
    void verify (void) const;
    void import_from_xml (const xml::node &n);
    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;
    void set_id (const char *id);

    void set_names (const std::list<std::string> &names)	{ names_ = names;				}
    void add_option (const option &o)				{ options_.push_back(o);			}
    const std::list<option>& get_options (void) const		{ return options_;				}
    void remove_option (const char *id)				{ options_.remove_if(find_by_id<option>(id));	}
    void add_group (const group &g)				{ groups_.push_back(g);				}
    const std::list<group>& get_groups (void) const		{ return groups_;				}
    void remove_group (const char *id)				{ groups_.remove_if(find_by_id<group>(id));	}
    const char* get_id (void) const				{ return id_.c_str();				}
    const std::list<std::string>& get_names (void) const	{ return names_;				}
    void set_description (const std::list<std::string> &paras)	{ desc_paras_ = paras;				}
    const std::list<std::string>& get_description (void) const	{ return desc_paras_;				}
    void set_comment (const char *comment)			{ comment_ = comment;				}
    const char* get_comment (void) const			{ return comment_.c_str();			}
private:
    std::string id_;
    std::string comment_;
    std::list<std::string> names_;
    std::list<option> options_;
    std::list<group> groups_;
    std::list<std::string> desc_paras_;

    void add_name (const char *name);
};
//####################################################################
cloxx::command::command (const xml::node &n) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->import_from_xml(n);
    ap.release();
}
//####################################################################
cloxx::command::command (const char *id) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->set_id(id);
    ap.release();
}
//####################################################################
cloxx::command::command (const command &other) {
    pimpl_ = new pimpl(*(other.pimpl_));
}
//####################################################################
cloxx::command& cloxx::command::operator= (const command &other) {
    command tmp(other);
    swap(tmp);
    return *this;
}
//####################################################################
void cloxx::command::swap (command &other) {
    std::swap(pimpl_, other.pimpl_);
}
//####################################################################
cloxx::command::~command (void) {
    delete pimpl_;
}
//####################################################################
/*
 * Bridge Functions
 */
void cloxx::command::verify (void) const				    { pimpl_->verify();			}
void cloxx::command::export_to_xml (xml::node &n) const			    { pimpl_->export_to_xml(n);		}
void cloxx::command::export_to_tpt (TPT::Object &o) const		    { pimpl_->export_to_tpt(o);		}
void cloxx::command::set_id (const char *id)				    { pimpl_->set_id(id);		}
const char* cloxx::command::get_id (void) const				    { return pimpl_->get_id();		}
void cloxx::command::set_names (const std::list<std::string> &names)	    { pimpl_->set_names(names);		}
const std::list<std::string>& cloxx::command::get_names (void) const	    { return pimpl_->get_names();	}
void cloxx::command::add_option (const option &o)			    { pimpl_->add_option(o);		}
const std::list<cloxx::option>& cloxx::command::get_options (void) const    { return pimpl_->get_options();	}
void cloxx::command::remove_option (const char *id)			    { pimpl_->remove_option(id);	}
void cloxx::command::add_group (const group &g)				    { pimpl_->add_group(g);		}
const std::list<cloxx::group>& cloxx::command::get_groups (void) const	    { return pimpl_->get_groups();	}
void cloxx::command::remove_group (const char *id)			    { pimpl_->remove_group(id);		}
void cloxx::command::set_description (const std::list<std::string> &paras)  { pimpl_->set_description(paras);	}
const std::list<std::string>& cloxx::command::get_description (void) const  { return pimpl_->get_description();	}
void cloxx::command::set_comment (const char *comment)			    { pimpl_->set_comment(comment);	}
const char* cloxx::command::get_comment (void) const			    { return pimpl_->get_comment();	}
//####################################################################
void cloxx::command::pimpl::verify (void) const {
    // make sure there are names for this command
    if (names_.empty()) {
	std::string error("the command '"); error += id_; error += "' has no names";
	throw std::runtime_error(error);
    }

    // make sure that all option names are unique within this command
    std::set<std::string> nameset;
    std::for_each(options_.begin(), options_.end(), uniq_name_check(id_.c_str(), nameset));
    nested_for_each(groups_.begin(), groups_.end(), uniq_name_check(id_.c_str(), nameset));
}
//####################################################################
void cloxx::command::pimpl::import_from_xml (const xml::node &n) {
    xml::attributes::const_iterator id_it(n.get_attributes().find(const_attr_id));
    set_id(id_it == n.get_attributes().end() ? 0 : id_it->get_value());

    xml::node::const_iterator i(n.begin()), end(n.end());
    for (; i!= end; ++i) {
	if (std::strcmp(i->get_name(), const_tag_name) == 0) {
	    add_name(i->get_content());
	} else if (std::strcmp(i->get_name(), const_tag_option) == 0) {
	    add_option(option(*i));
	} else if (std::strcmp(i->get_name(), const_tag_group) == 0) {
	    add_group(group(*i));
	} else if (std::strcmp(i->get_name(), const_tag_description) == 0) {
	    import_description(*i, desc_paras_);
	} else if (std::strcmp(i->get_name(), const_tag_comment) == 0) {
	    comment_ = i->get_content();
	    cxxtools::normalize(comment_);
	}
    }

    verify();
}
//####################################################################
void cloxx::command::pimpl::export_to_xml (xml::node &n) const {
    n.get_attributes().insert(const_attr_id, get_id());

    std::list<std::string>::const_iterator ni(names_.begin()), ne(names_.end());
    for (; ni != ne; ++ni) n.push_back(xml::node(const_tag_name, ni->c_str()));

    if (!comment_.empty()) n.push_back(xml::node(const_tag_comment, comment_.c_str()));
    export_description(n, desc_paras_);

    std::list<option>::const_iterator oi(options_.begin()), oe(options_.end());
    for (; oi != oe; ++oi) {
	xml::node option_node(const_tag_option);
	oi->export_to_xml(option_node);
	n.push_back(option_node);
    }

    std::list<group>::const_iterator gi(groups_.begin()), ge(groups_.end());
    for (; gi != ge; ++gi) {
	xml::node group_node(const_tag_group);
	gi->export_to_xml(group_node);
	n.push_back(group_node);
    }
}
//####################################################################
void cloxx::command::pimpl::export_to_tpt (TPT::Object &o) const {
    TPT::Object::PtrType command_hash = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::PtrType options_hash = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::PtrType groups_hash  = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::PtrType names_array  = new TPT::Object(TPT::Object::type_array);

    std::list<std::string>::const_iterator ni(names_.begin()), ne(names_.end());
    for (; ni != ne; ++ni) names_array.get()->array().push_back(new TPT::Object(*ni));
    command_hash.get()->hash()["names"] = names_array;

    if (!comment_.empty()) command_hash.get()->hash()[const_tag_comment] = new TPT::Object(comment_);
    export_description(*(command_hash.get()), desc_paras_);

    command_hash.get()->hash()["options"] = options_hash;
    command_hash.get()->hash()["groups"]  = groups_hash;
    o.hash()["commands"].get()->hash()[id_] = command_hash;

    std::for_each(options_.begin(), options_.end(), tpt_export<option>(*(command_hash.get())));
    std::for_each(groups_.begin(), groups_.end(),   tpt_export<group>(*command_hash.get()));

    command_hash.get()->hash()[const_attr_id] = new TPT::Object(get_id());
}
//####################################################################
void cloxx::command::pimpl::set_id (const char *id) {
    if (!id) throw std::runtime_error("blank or missing command/@id");
    
    id_ = id;
    cxxtools::normalize(id_);

    if (id_.empty()) throw std::runtime_error("blank command/@id");
}
//####################################################################
void cloxx::command::pimpl::add_name (const char *name) {
    if (!name) throw std::runtime_error("blank or missing command/name");

    std::string sname(name);
    cxxtools::normalize(sname);

    if (sname.empty()) throw std::runtime_error("blank command/name");
    names_.push_back(sname);
}
