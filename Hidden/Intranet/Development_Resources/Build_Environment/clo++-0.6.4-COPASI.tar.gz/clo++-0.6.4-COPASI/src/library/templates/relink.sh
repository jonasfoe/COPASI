#! /bin/sh
sh convert.sh
(cd ../; make) && (cd ../../cmdline/; rm -f clo++; make)
