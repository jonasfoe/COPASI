/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::usage class
**/

// cloxx includes
#include "usage.h"

// cxxtools
#include <cxxtools/strutil.h>

// standard includes
#include <algorithm>

//####################################################################
namespace {
    struct visit_option {
	visit_option (std::map<std::string, std::string> &usage_map)
	    : usage_map_(usage_map) {  }

	void operator() (const cloxx::option &op)
	{ if (op.get_hidden()) return; usage_map_[op.get_signature()] = op.get_comment(); }

	void operator() (const cloxx::group &grp)
	{ std::for_each(grp.get_options().begin(), grp.get_options().end(), *this); }

	std::map<std::string, std::string> &usage_map_;
    };

    struct max_compare {
	bool operator() (const std::pair<std::string, std::string> &a, const std::pair<std::string, std::string> &b)
	{ return a.first.size() < b.first.size(); }
    };
}
//####################################################################
void cloxx::usage::operator() (const app &a) {
    visit_option vo(usage_map_);

    std::for_each(a.get_options().begin(), a.get_options().end(), vo);
    std::for_each(a.get_groups().begin(),  a.get_groups().end(),  vo);

    const std::list<command> &commands = a.get_commands();
    if (a.get_config().get_autohelp_state() && !commands.empty()) {
	std::string help_commands("--help-commands");
	std::string help_synonyms("--help-synonyms");

	const config::variable_table &vt = a.get_config().get_variables();
	config::variable_table::const_iterator vit;

	if ( (vit = vt.find("help-commands")) != vt.end()) {
	    usage_map_[help_commands] = vit->second;
	} else {
	    usage_map_[help_commands] = "get a list of commands";
	}

	if ( (vit = vt.find("help-synonyms")) != vt.end()) {
	    usage_map_[help_synonyms] = vit->second;
	} else {
	    usage_map_[help_synonyms] = "get a list of command synonyms";
	}
    }
	
    gen_string();
}
//####################################################################
void cloxx::usage::operator() (const command &c) {
    visit_option vo(usage_map_);

    std::for_each(c.get_options().begin(), c.get_options().end(), vo);
    std::for_each(c.get_groups().begin(),  c.get_groups().end(),  vo);

    gen_string();
}
//####################################################################
void cloxx::usage::make_cstring (void) {
    cxxtools::quotemeta(output_);
    output_.insert(0, "\"");

    std::string::size_type pos, last_stop=0;
    while ( (pos = output_.find('\n', last_stop)) != std::string::npos) {
	if (pos == (output_.size() - 1)) {
	    output_.insert(pos, "\\n\"");
	    break;
	}

	output_.insert(pos, "\\n\""); pos += 4;
	output_.insert(pos, "\"");
	last_stop = pos;
    }

    output_.erase(output_.size() - 1);
}
//####################################################################
void cloxx::usage::make_command_list (const app &a) {
    const std::list<command> &commands = a.get_commands();
    std::list<command>::const_iterator it(commands.begin()), end(commands.end());

    for (; it != end; ++it) {
	const std::list<std::string> &names = it->get_names();
	if (names.empty()) continue;
	usage_map_[*(names.begin())] = it->get_comment();
    }

    gen_string();
}
//####################################################################
void cloxx::usage::make_command_syns (const app &a) {
    const std::list<command> &commands = a.get_commands();
    std::list<command>::const_iterator it(commands.begin()), end(commands.end());

    for (; it != end; ++it) {
	const std::list<std::string> &names = it->get_names();
	if (names.empty()) continue;

	std::list<std::string>::const_iterator names_it(names.begin()), names_end(names.end());
	std::string key(*names_it); ++names_it;
	std::string value;

	if (names_it == names_end) {
	    value = "there are no synonyms for this command";
	} else {
	    value = cxxtools::join(std::string(", "), names_it, names_end);
	}

	usage_map_[key] = value;
    }

    gen_string();
}
//####################################################################
void cloxx::usage::gen_string (void) {
    std::map<std::string, std::string>::const_iterator max_sig_it = 
	std::max_element(usage_map_.begin(), usage_map_.end(), max_compare());

    if (max_sig_it == usage_map_.end()) return;
    std::map<std::string, std::string>::size_type max_sig = max_sig_it->first.size() + 2;

    std::vector<char> sigspace(max_sig + 2, ' ');
    std::string prefix(&sigspace[0], max_sig + 2);

    std::map<std::string, std::string>::const_iterator uit(usage_map_.begin()), uend(usage_map_.end());
    for (; uit != uend; ++uit) {
	std::string tmp_string("  "); tmp_string += uit->first;

	if (tmp_string.size() < max_sig) {
	    tmp_string.append(&sigspace[0], max_sig - tmp_string.size());
	}

	tmp_string += "  ";
	tmp_string += uit->second;

	cxxtools::wrap(tmp_string, 76, prefix);
	if (tmp_string[tmp_string.size() - 1] != '\n') tmp_string += '\n';
	output_ += tmp_string;
    }
}
