/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the implementation of the cloxx::app class.
**/

// cloxx includes
#include <cloxx/app.h>
#include <cloxx/command.h>
#include <cloxx/group.h>
#include <cloxx/option.h>
#include <cloxx/config.h>
#include "common.h"

// xmlwrapp includes
#include <xmlwrapp/xmlwrapp.h>

// libtpt includes
#include <libtpt/object.h>

// cxxtools includes
#include <cxxtools/strutil.h>

// standard includes
#include <set>
#include <list>
#include <memory>
#include <string>
#include <cstring>
#include <algorithm>
#include <stdexcept>

//####################################################################
namespace {
    const char const_tag_options[]	    = "options";
    const char const_tag_config[]	    = "config";
    const char const_tag_program[]	    = "program";
    const char const_tag_heading[]	    = "heading";
    const char const_program_name[]	    = "name";
    const char const_main_command_id[]	    = "__toplevel__";

    const char const_top_headings_list[]    = "top_heading_order";
    const char const_top_headings[]	    = "top_headings";
    const char const_bottom_headings_list[] = "bottom_heading_order";
    const char const_bottom_headings[]	    = "bottom_headings";

    const char const_heading_title[]	    = "title";
    const char const_heading_location[]	    = "location";
    const char const_heading_top[]	    = "top";
    const char const_heading_bottom[]	    = "bottom";

    struct collect_autothrow {
	collect_autothrow (std::vector<std::string> &autothrow_ids)
	    : at_ids_(autothrow_ids)
	{ }

	void operator() (const cloxx::option &op) {
	    std::string tmp = op.get_autothrow_id();
	    if (!tmp.empty()) at_ids_.push_back(tmp);
	}

	std::vector<std::string> &at_ids_;
    };

    template<typename T> struct uniq_id_check {
	uniq_id_check(std::set<std::string> &s)
	    : set_(s) { }

	void operator() (const T &t) {
	    std::pair<std::set<std::string>::iterator, bool> status = set_.insert(t.get_id());

	    if (!status.second) {
		std::string error("duplicate id '"); error += t.get_id(); error += "' found, all id's should be unique";
		throw std::runtime_error(error);
	    }
	}

	std::set<std::string> &set_;
    };
}
//####################################################################
class cloxx::app::pimpl {
public:
    pimpl (void)
	: main_command_(const_main_command_id)
    {
	// make the main command happy
	std::list<std::string> names; names.push_back(const_main_command_id);
	main_command_.set_names(names);
    }

    void import_from_xml (const xml::node &n);
    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;

    void set_heading (const heading &h);
    bool get_heading (const char *title, heading &h) const;

    void set_comment (const char *comment);

    const char* get_comment (void) const		{ return comment_.c_str();			}
    void reset_headings (void)				{ headings_.clear();				}
    const std::list<heading>& get_headings (void) const	{ return headings_;				}

    void set_config (const config &c)			{ config_ = c;					}
    const config& get_config (void) const		{ return config_;				}

    void add_option (const option &o)			{ main_command_.add_option(o);			}
    const std::list<option>& get_options (void) const	{ return main_command_.get_options();		}
    void remove_option (const char *id)			{ main_command_.remove_option(id);		}
    
    void add_group (const group &g)			{ main_command_.add_group(g);			}
    const std::list<group>& get_groups (void) const	{ return main_command_.get_groups();		}
    void remove_group (const char *id)			{ main_command_.remove_group(id);		}

    void add_command (const command &c)			{ commands_.push_back(c);			}
    const std::list<command>& get_commands (void) const	{ return commands_;				}
    void remove_command (const char *id)		{ commands_.remove_if(find_by_id<command>(id)); }

    void set_name (const char *program_name)		{ name_ = program_name;				}
    const char* get_name (void) const			{ return name_.c_str();				}
private:
    command main_command_;

    std::list<command> commands_;
    config config_;
    std::string name_;
    std::string comment_;
    std::list<heading> headings_;

    void import_program (const xml::node &n);
    void export_program (xml::node &n) const;
    void export_program (TPT::Object &obj) const;
};
//####################################################################
cloxx::app::app (const xml::node &n) {
    std::auto_ptr<pimpl> ap(pimpl_ = new pimpl);
    pimpl_->import_from_xml(n);
    ap.release();
}
//####################################################################
cloxx::app::app (void) {
    pimpl_ = new pimpl;
}
//####################################################################
cloxx::app::app (const app &other) {
    pimpl_ = new pimpl(*(other.pimpl_));
}
//####################################################################
cloxx::app& cloxx::app::operator= (const app &other) {
    app tmp(other);
    swap(tmp);
    return *this;
}
//####################################################################
void cloxx::app::swap (app &other) {
    std::swap(pimpl_, other.pimpl_);
}
//####################################################################
cloxx::app::~app (void) {
    delete pimpl_;
}
//####################################################################

/*
 * Bridge Functions
 */
namespace cloxx {
    void app::export_to_xml (xml::node &n) const			{ pimpl_->export_to_xml(n);		}
    void app::export_to_tpt (TPT::Object &o) const			{ pimpl_->export_to_tpt(o);		}
    void app::set_config (const config &c)				{ pimpl_->set_config(c);		}
    const config& app::get_config (void) const				{ return pimpl_->get_config();		}
    void app::add_option (const option &o)				{ pimpl_->add_option(o);		}
    const std::list<option>& app::get_options (void) const		{ return pimpl_->get_options();		}
    void app::remove_option (const char *id)				{ pimpl_->remove_option(id);		}
    void app::add_group (const group &g)				{ pimpl_->add_group(g);			}
    const std::list<group>& app::get_groups (void) const		{ return pimpl_->get_groups();		}
    void app::remove_group (const char *id)				{ pimpl_->remove_group(id);		}			
    void app::add_command (const command &c)				{ pimpl_->add_command(c);		}	
    const std::list<command>& app::get_commands (void) const		{ return pimpl_->get_commands();	}
    void app::remove_command (const char *id)				{ pimpl_->remove_command(id);		}
    void app::set_name (const char *program_name)			{ pimpl_->set_name(program_name);	}
    const char* app::get_name (void) const				{ return pimpl_->get_name();		}
    void app::set_comment (const char *comment)				{ pimpl_->set_comment(comment);		}
    const char* app::get_comment (void) const				{ return pimpl_->get_comment();		}
    void app::reset_headings (void)					{ pimpl_->reset_headings();		}
    const std::list<app::heading>& app::get_headings (void) const	{ return pimpl_->get_headings();	}
    void app::set_heading (const heading &h)				{ pimpl_->set_heading(h);		}
    bool app::get_heading (const char *title, heading &h) const		{ return pimpl_->get_heading(title, h);	}
}
//####################################################################
cloxx::app::heading::heading (void)
    : loc(location_top)
{ }
//####################################################################
cloxx::app::heading::heading (const xml::node &n) 
    : loc(location_top)
{
    xml::attributes::const_iterator title_it(n.get_attributes().find(const_heading_title));
    if (title_it == n.get_attributes().end()) throw std::runtime_error("missing program/heading/@title");
    title = title_it->get_value();

    xml::attributes::const_iterator loc_it(n.get_attributes().find(const_heading_location));
    if (loc_it != n.get_attributes().end()) {
	switch (*loc_it->get_value()) {
	case 't':
	    loc = location_top;
	    break;
	case 'b':
	    loc = location_bottom;
	    break;
	default:
	    {
		std::string error("unknown heading location value '"); error += loc_it->get_value(); error += "'";
		throw std::runtime_error(error);
	    }
	}
    }

    import_description(n, paras);
}
//####################################################################
bool cloxx::app::heading::operator== (const char *t) const {
    return std::strcmp(t, title.c_str()) == 0;
}
//####################################################################
void cloxx::app::heading::export_to_xml (xml::node &n) const {
    xml::node heading_node(const_tag_heading);
    heading_node.get_attributes().insert(const_heading_title, title.c_str());

    switch (loc) {
    case location_top:
	heading_node.get_attributes().insert(const_heading_location, const_heading_top);
	break;
    case location_bottom:
	heading_node.get_attributes().insert(const_heading_location, const_heading_bottom);
	break;
    }

    std::list<std::string>::const_iterator pi(paras.begin()), pend(paras.end());
    for (; pi != pend; ++pi) heading_node.push_back(xml::node(const_tag_para, pi->c_str()));

    n.push_back(heading_node);
}
//####################################################################
void cloxx::app::heading::export_to_tpt (TPT::Object &obj) const {
    TPT::Object::PtrType parasobj = new TPT::Object(TPT::Object::type_array);
    TPT::Object *heading_list(0), *heading_hash(0);

    switch (loc) {
    case location_top:
	heading_list = obj.hash()[const_top_headings_list].get();
	heading_hash = obj.hash()[const_top_headings].get();
	break;
    case location_bottom:
	heading_list = obj.hash()[const_bottom_headings_list].get();
	heading_hash = obj.hash()[const_bottom_headings].get();
	break;
    }

    std::list<std::string>::const_iterator pi(paras.begin()), pend(paras.end());
    for (; pi != pend; ++pi) parasobj.get()->array().push_back(new TPT::Object(*pi));

    heading_list->array().push_back(new TPT::Object(title));
    heading_hash->hash()[title] = parasobj;
}
//####################################################################
void cloxx::app::pimpl::import_from_xml (const xml::node &n) {
    xml::node::const_iterator i(n.begin()), end(n.end());
    for (; i != end; ++i) {
	if (std::strcmp(i->get_name(), const_tag_program) == 0) {
	    import_program(*i);
	} else if (std::strcmp(i->get_name(), const_tag_config) == 0) {
	    config_.import_from_xml(*i);
	} else if (std::strcmp(i->get_name(), const_tag_options) == 0) {
	    xml::node::const_iterator oi(i->begin()), oe(i->end());
	    for (; oi != oe; ++oi) {
		if (std::strcmp(oi->get_name(), const_tag_option) == 0) {
		    add_option(option(*oi));
		}
	    }
	} else if (std::strcmp(i->get_name(), const_tag_group) == 0) {
	    add_group(group(*i));
	} else if (std::strcmp(i->get_name(), const_tag_command) == 0) {
	    add_command(command(*i));
	}
    }

    main_command_.verify();

    // check to make sure that all id's are unique
    std::set<std::string> idset;

    std::for_each(main_command_.get_options().begin(), main_command_.get_options().end(), uniq_id_check<option>(idset));
    std::for_each(main_command_.get_groups().begin(),  main_command_.get_groups().end(),  uniq_id_check<group>(idset));
    nested_for_each(main_command_.get_groups().begin(), main_command_.get_groups().end(), uniq_id_check<option>(idset));
    std::for_each(commands_.begin(), commands_.end(), uniq_id_check<command>(idset));

    std::list<command>::const_iterator command_it(commands_.begin()), command_end(commands_.end());
    for (; command_it != command_end; ++command_it) {
	std::for_each(command_it->get_options().begin(), command_it->get_options().end(), uniq_id_check<option>(idset));
	std::for_each(command_it->get_groups().begin(),  command_it->get_groups().end(),  uniq_id_check<group>(idset));
	nested_for_each(command_it->get_groups().begin(), command_it->get_groups().end(), uniq_id_check<option>(idset));
    }
}
//####################################################################
void cloxx::app::pimpl::export_to_xml (xml::node &n) const {
    const std::list<option> &options = get_options();
    const std::list<group>  &groups  = get_groups();

    export_program(n);

    xml::node config_node(const_tag_config);
    config_.export_to_xml(config_node);
    n.push_back(config_node);

    xml::node options_node(const_tag_options);
    std::list<option>::const_iterator oi(options.begin()), oe(options.end());
    for (; oi != oe; ++oi) {
	xml::node opnode(const_tag_option);
	oi->export_to_xml(opnode);
	options_node.push_back(opnode);
    }
    n.push_back(options_node);

    std::list<group>::const_iterator gi(groups.begin()), ge(groups.end());
    for (; gi != ge; ++gi) {
	xml::node group_node(const_tag_group);
	gi->export_to_xml(group_node);
	n.push_back(group_node);
    }

    std::list<command>::const_iterator ci(commands_.begin()), ce(commands_.end());
    for (; ci != ce; ++ci) {
	xml::node command_node(const_tag_command);
	ci->export_to_xml(command_node);
	n.push_back(command_node);
    }
}
//####################################################################
void cloxx::app::pimpl::export_to_tpt (TPT::Object &o) const {
    export_program(o);
    config_.export_to_tpt(o);

    const std::list<option> &options = get_options();
    const std::list<group>  &groups  = get_groups();

    TPT::Object::PtrType options_hash = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::PtrType commands_hash = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::PtrType groups_hash = new TPT::Object(TPT::Object::type_hash);

    o.hash()["options"] = options_hash;
    o.hash()["commands"] = commands_hash;
    o.hash()["groups"] = groups_hash;

    std::for_each(options.begin(), options.end(), tpt_export<option>(o));
    std::for_each(groups.begin(), groups.end(), tpt_export<group>(o));
    std::for_each(commands_.begin(), commands_.end(), tpt_export<command>(o));

    /*
     * collect all options that are "autothrow" options and make a list of
     * them for the tpt templates/
     */
    std::vector<std::string> autothrow_ids;
    collect_autothrow ca(autothrow_ids);

    if (config_.get_autohelp_state())
	autothrow_ids.push_back(config_.get_autohelp_id());

    std::for_each(main_command_.get_options().begin(), main_command_.get_options().end(), ca);
    nested_for_each(main_command_.get_groups().begin(), main_command_.get_groups().end(), ca);

    std::list<command>::const_iterator commands_it(commands_.begin()), commands_end(commands_.end());
    for (; commands_it != commands_end; ++commands_it) {
	std::for_each(commands_it->get_options().begin(), commands_it->get_options().end(), ca);
	nested_for_each(commands_it->get_groups().begin(), commands_it->get_groups().end(), ca);
    }

    if (!autothrow_ids.empty()) {
	TPT::Object::PtrType ids = new TPT::Object(TPT::Object::type_array);
	std::vector<std::string>::const_iterator id_it(autothrow_ids.begin()), id_end(autothrow_ids.end());
	for (; id_it != id_end; ++id_it) ids.get()->array().push_back(new TPT::Object(*id_it));

	o.hash()["autothrow"] = ids;
    }
}
//####################################################################
void cloxx::app::pimpl::set_heading (const heading &h) {
    std::list<heading>::iterator i = std::find(headings_.begin(), headings_.end(), h.title.c_str());

    if (i != headings_.end()) *i = h;
    else headings_.push_back(h);
}
//####################################################################
bool cloxx::app::pimpl::get_heading (const char *title, heading &h) const {
    std::list<heading>::const_iterator i = std::find(headings_.begin(), headings_.end(), title);

    if (i != headings_.end()) {
	h = *i;
	return true;
    }

    return false;
}
//####################################################################
void cloxx::app::pimpl::set_comment (const char *comment) {
    if (!comment) throw std::runtime_error("blank or missing program/comment");
    
    comment_ = comment;
    cxxtools::normalize(comment_);

    if (!comment_.size()) throw std::runtime_error("blank program/comment");
}
//####################################################################
void cloxx::app::pimpl::import_program (const xml::node &n) {
    xml::attributes::const_iterator name_it(n.get_attributes().find(const_program_name));
    if (name_it != n.get_attributes().end()) { name_ = name_it->get_value(); cxxtools::normalize(name_); }

    xml::node::const_iterator node_it(n.begin()), node_end(n.end());
    for (; node_it != node_end; ++node_it) {
	if (std::strcmp(node_it->get_name(), const_tag_heading) == 0) {
	    headings_.push_back(heading(*node_it));
	} else if (std::strcmp(node_it->get_name(), const_tag_comment) == 0) {
	    set_comment(node_it->get_content());
	}
    }
}
//####################################################################
void cloxx::app::pimpl::export_program (xml::node &n) const {
    xml::node program_node(const_tag_program);

    if (!name_.empty())	    program_node.get_attributes().insert(const_program_name, name_.c_str());
    if (!comment_.empty())  program_node.push_back(xml::node(const_tag_comment, comment_.c_str()));

    std::list<heading>::const_iterator hi(headings_.begin()), hend(headings_.end());
    for (; hi != hend; ++hi) hi->export_to_xml(program_node);

    n.push_back(program_node);
}
//####################################################################
void cloxx::app::pimpl::export_program (TPT::Object &obj) const {
    if (!name_.empty())	    obj.hash()[const_program_name] = new TPT::Object(name_);
    if (!comment_.empty())  obj.hash()[const_tag_comment] = new TPT::Object(comment_);

    TPT::Object::PtrType heading_top_list = new TPT::Object(TPT::Object::type_array);
    TPT::Object::PtrType heading_top_hash = new TPT::Object(TPT::Object::type_hash);
    TPT::Object::PtrType heading_bottom_list = new TPT::Object(TPT::Object::type_array);
    TPT::Object::PtrType heading_bottom_hash = new TPT::Object(TPT::Object::type_hash);

    obj.hash()[const_top_headings_list]	    = heading_top_list;
    obj.hash()[const_top_headings]	    = heading_top_hash;
    obj.hash()[const_bottom_headings_list]  = heading_bottom_list;
    obj.hash()[const_bottom_headings]	    = heading_bottom_hash;

    std::list<heading>::const_iterator hi(headings_.begin()), hend(headings_.end());
    for (; hi != hend; ++hi) hi->export_to_tpt(obj);
}
