/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the definition of the cloxx::option class.
**/

#ifndef __cloxx_option_h__
#define __cloxx_option_h__

// xmlwrapp includes
#include <xmlwrapp/node.h>

// libtpt includes
#include <libtpt/object.h>

// standard includes
#include <map>
#include <list>
#include <string>

namespace cloxx {

/**
 * The cloxx::option class is used to hold information about one option.
**/
class option {
public:
    typedef std::map<std::string, std::string> enum_table;

    /// possible option types
    enum types {
	type_flag,		///< Flag, on command line or not
	type_bool,		///< Bool, takes a string that indicates bool state
	type_enum,		///< Enum, takes a vaule that must be in a static set
	type_int,		///< Int, takes an integer
	type_double,		///< Double, takes a double presision floating point number
	type_string		///< String, takes non-parsed character data
    };

    /// possible option modifiers
    enum modifiers {
	modifier_none,		///< No modifer
	modifier_vector,	///< Vector, option may be repeated
	modifier_map		///< Map, option takes a key and value
    };

    /// possible option locations
    enum locations {
	location_command_line,	///< The option is only for the command line
	location_config_file,	///< The option is only for a config file
	location_both		///< The option can be on the command line or in a config file
    };

    explicit option (const xml::node &option_node);
    explicit option (const char *id);
    option (const option &other);
    option& operator= (const option &other);
    void swap (option &other);
    ~option (void);

    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;

    void set_id (const char *id);
    void set_type (types t);
    void set_modifier (modifiers m);
    void set_mandatory (bool mandatory);
    void set_names (const std::list<std::string> &names);
    void set_default (const char *d);
    void set_hidden (bool hidden);
    void set_enum_table (const enum_table &enums);
    void set_argname (const char *argname);
    void set_range_min (const char *range_min);
    void set_range_max (const char *range_max);
    void set_description (const std::list<std::string> &paras);
    void set_comment (const char *comment);
    void set_autothrow_id (const char *id);
    void set_strict (bool strict);

    const char* get_id (void) const;
    types get_type (void) const;
    modifiers get_modifier (void) const;
    bool get_mandatory (void) const;
    const std::list<std::string>& get_names (void) const;
    const char* get_default (void) const;
    bool get_hidden (void) const;
    const enum_table& get_enum_table (void) const;
    const char* get_argname (void) const;
    const char* get_range_min (void) const;
    const char* get_range_max (void) const;
    const std::list<std::string>& get_description (void) const;
    const char* get_comment (void) const;
    const char* get_autothrow_id (void) const;
    bool get_strict (void) const;

    const char* get_signature (void) const;
private:
    class pimpl; pimpl *pimpl_;
}; // end cloxx::option class

} // end cloxx namespace
#endif
