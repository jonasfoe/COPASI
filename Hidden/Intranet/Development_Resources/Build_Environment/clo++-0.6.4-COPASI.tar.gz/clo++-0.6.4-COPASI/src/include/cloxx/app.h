/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * The file contains the defintion of the cloxx::app class.
**/

#ifndef __cloxx_app_h__
#define __cloxx_app_h__

// cloxx includes
#include <cloxx/option.h>
#include <cloxx/group.h>
#include <cloxx/command.h>
#include <cloxx/config.h>

// includes for exporting
#include <xmlwrapp/node.h>
#include <libtpt/object.h>

// standard includes
#include <list>

namespace cloxx {

/**
 * The cloxx::app class is used to hold information about the application.
 * This includes the main options and groups. It also is a container for
 * sub-commands.
**/
class app {
public:
    struct heading {
	heading (void);
	explicit heading (const xml::node &n);

	void export_to_xml (xml::node &n) const;
	void export_to_tpt (TPT::Object &obj) const;
	bool operator== (const char *t) const;

	enum location {
	    location_top,
	    location_bottom
	}			loc;
	std::string		title;
	std::list<std::string>	paras;
    };

    explicit app (const xml::node &n);
    app (void);
    app (const app &other);
    app& operator= (const app &other);
    void swap (app &other);
    ~app (void);

    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;

    void set_name (const char *program_name);
    const char* get_name (void) const;

    void set_comment (const char *comment);
    const char* get_comment (void) const;

    const std::list<heading>& get_headings (void) const;
    void reset_headings (void);
    void set_heading (const heading &h);
    bool get_heading (const char *title, heading &h) const;

    void set_config (const config &c);
    const config& get_config (void) const;

    void add_option (const option &o);
    const std::list<option>& get_options (void) const;
    void remove_option (const char *id);

    void add_group (const group &g);
    const std::list<group>& get_groups (void) const;
    void remove_group (const char *id);

    void add_command (const command &c);
    const std::list<command>& get_commands (void) const;
    void remove_command (const char *id);
private:
    class pimpl; pimpl *pimpl_;
};

} // end cloxx namespace
#endif
