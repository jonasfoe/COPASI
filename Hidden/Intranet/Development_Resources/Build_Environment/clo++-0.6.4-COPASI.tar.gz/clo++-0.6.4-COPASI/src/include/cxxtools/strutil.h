/*
 * Copyright (C) 2001-2002 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains some utility functions for working with std::string
 * like classes. I say std::string like because these functions are template
 * based so they can work with any string class that supports the
 * std::string interface.
 *
 * This file is part of the cxxtools project.
 * http://pmade.org/pjones/software/cxxtools/
 *
 * $Id: strutil.h,v 1.8 2002/04/01 17:07:43 pjones Exp $
**/

#ifndef __cxxtools_strutil_h__
#define __cxxtools_strutil_h__

// standard includes
#include <cctype>
#include <cstring>
#include <algorithm>

namespace cxxtools {

//#############################################################################
/**
 * Remove space from a string
 *
 * This utility function will remove space from a string starting at
 * the position pos until a non-space character. It uses isspace to
 * work.
 * 
 * @param s The string
 * @param pos Where to start (defaults to zero)
 * @author Peter Jones
**/
//#############################################################################
template <typename T>
void rm_space_forward (T &s, typename T::size_type pos=0) {
    while (pos < s.size()) {
	if (std::isspace(s[pos])) s.erase(pos, 1);
	else break;
    }
}
//#############################################################################
/**
 * Remove space from a string backward
 *
 * This utility function will remove space from a string starting at pos
 * and moving backward until a non-space character is found. It uses
 * isspace to work.
 *
 * @param s The string
 * @param pos Where to start (defaults to zero, which means start at the
 * last char)
 * @author Peter Jones
 **/
//#############################################################################
template <typename T>
void rm_space_reverse (T &s, typename T::size_type pos=0) {
    if (s.empty()) return;
    if (pos == 0) pos = s.size() - 1;

    for (;;) {
	if (std::isspace(s[pos])) s.erase(pos, 1);
	else break;

	if (pos == 0) break;
	else --pos;
    }
}
//#############################################################################
/**
 * Remove space before and after a newline
 *
 * This utility function will remove space before and after each newline in
 * the string. It also replaces the newline with a space.
 *
 * @param s a string
 * @author Peter Jones
 **/
//#############################################################################
template <typename T>
void rm_space_newline(T &s) {
    typename T::size_type pos;

    while ( (pos = s.find('\n')) != T::npos) {
	s[pos] = ' ';
	rm_space_forward(s, pos+1);
	if (pos != 0) rm_space_reverse(s, pos-1);

	if ((pos + 1) == s.size()) {
	    s.erase(pos); break;
	}

    }
}
//#############################################################################
/**
 * Turn multiple spaces into one space. This utility function will remove
 * extra spaces.
 *
 * @param s the string
 * @author Peter Jones
 **/
//#############################################################################
template <typename T>
void rm_space_dup (T &s) {
    typename T::size_type pos = 0;
    typename T::size_type size = s.size();

    while ((pos+1) < size) {
	if (std::isspace(s[pos]) && std::isspace(s[pos + 1])) {
	    s.erase(pos+1, 1);
	    size = s.size();
	    continue;
	}

	pos++;
    }
}
//####################################################################
/** 
 * normalize a string. This function will remove all unnecessary whitespace
 * in a string. This includes newlines.
 *
 * @param s The string to normailze
 * @author Peter Jones
**/
//####################################################################
template <typename T>
void normalize (T &s) {
    rm_space_newline(s);
    rm_space_forward(s);
    rm_space_reverse(s);
    rm_space_dup(s);
}
//#############################################################################
/**
 * Escape meta characters in a string. This utility function will esacpe
 * meta characters in a string so that it can be used inside C++ source.
 * 
 * @param s the string
 * @author Peter Jones
 **/
//#############################################################################
template <typename T>
void quotemeta(T &s) {
    typename T::size_type pos = 0;
    const char cpp_chars[] = "\"\\";

    while (pos < s.size()) {
	if (std::strchr(cpp_chars, s[pos]))
	    s.insert(pos++, "\\");

	++pos;
    }
}
//#############################################################################
/** 
 * Join a container of strings together. You can specify a string to "glue"
 * the strings together. This string will only be present inbetween the
 * strings, and not on the outsides
 * 
 * @param sep The "glue" string
 * @param begin_it An iterator that points to the first element to join
 * @param end_it An iterator that points one past the last element to join
 * @return a string containing the joined strings
 * @author Peter Jones
 *
 * @note PRECONDITION: begin_it != end_it and begin_it can be dereferenced.
 **/
//#############################################################################
template <typename T_, typename I_>
T_ join(const T_ &sep, I_ begin_it, I_ end_it) {
    T_ result;

    for (;;) {
	result += *begin_it; ++begin_it;
	if (begin_it == end_it) break;
	result += sep;
    }

    return result;
}
//####################################################################
/** 
 * Split a string using the given delimiter. The delimiter is another
 * string. The split parts are placed into the given vector.
 *
 * @param s The string to split
 * @param delimiter The string to split on
 * @param elements The container to place the split parts into
 * @param m The max number of elements to create (defaults to zero which
 *	    means no max)
 * @return The number of elements placed into the container
 * @author Peter Jones
 **/
//####################################################################
template <typename T, typename C>
typename T::size_type split (const T &s, const T &delimiter, C &elements, typename T::size_type m=0) {
    typename T::size_type pos_first(0), pos_second, count(0), delimiter_size(delimiter.size());

    while ( (pos_second = s.find(delimiter, pos_first)) != T::npos) {
	elements.push_back(s.substr(pos_first, pos_second - pos_first));
	pos_first = pos_second + delimiter_size + 1;
	++count; if (m && (count + 1) >= m) break;
    }

    if (pos_first < s.size()) {
	elements.push_back(s.substr(pos_first));
	++count;
    }

    return count;
}
//####################################################################
/** 
 * Convert all characters in the given string to uppercase.
 *
 * @param s The string to convert to uppercase
 * @author Peter Jones
 **/
//####################################################################
template <typename T>
void to_uppercase (T &s) {
    typename T::size_type i(0), size(s.size());
    for (; i < size; ++i) s[i] = std::toupper(s[i]);
}
//####################################################################
/** 
 * Conver all the charaters in the given string to lowercase.
 *
 * @param s The string to convert to lowercase.
 * @author Peter Jones
 **/
//####################################################################
template <typename T>
void to_lowercase (T &s) {
    typename T::size_type i(0), size(s.size());
    for (; i < size; ++i) s[i] = std::tolower(s[i]);
}
//####################################################################
/** 
 * Strip all occurances of a character from a string and return the
 * number of characters removed.
 *
 * @param s The string
 * @param strip The character to remove
 * @return The number of characters removed
 * @author Peter Jones
 **/
//####################################################################
template <typename T>
typename T::size_type char_strip (T &s, char strip) {
    typename T::size_type i(0), count(0);

    while ( (i = s.find(strip, i)) != T::npos) {
	s.erase(i, 1); ++count;
    }

    return count;
}
//####################################################################
/** 
 * This template function will wrap the given string to the given width. It
 * tries to break on word boundries as long as the word boundry is within 15
 * percent or 12 characters from the target width, which ever is less.
 *
 * You can give a prefix string that will be prepended to each new line that
 * is created. This means that it will not be prepeneded to the first line.
 *
 * The string that you pass in should be only one line, that is, it should
 * not have any line breaking characters. For best results, pass in a string
 * that does not contain and newlines or tabs and has been normilized in
 * reference to concurrent whitespace.
 *
 * @param s The string to wrap
 * @param width The target width
 * @param prefix The string to prefix to each new line.
 * @author Peter Jones
**/
//####################################################################
template <typename T>
void wrap (T &s, typename T::size_type width, const T &prefix) {
    T word_boundries = ",- \t\n";
    typename T::size_type current_pos(0), line_pos(0), last_wb(0);
    typename T::size_type size(s.size()), psize(prefix.size());
    typename T::size_type max_last_wb = std::min(
	    static_cast<typename T::size_type>(width * 0.15), 
	    static_cast<typename T::size_type>(12));

    while (current_pos < size) {
	if (line_pos >= width) {
	    // last_wb is no good if it is too far away.
	    if (last_wb != 0 && current_pos - last_wb > max_last_wb)
		last_wb = 0;

	    if (last_wb == 0) {
		s.insert(current_pos, "-\n" + prefix);
		current_pos += 3 + psize;
		line_pos = psize;
	    } else {
		if (std::isspace(s[last_wb])) {
		    s[last_wb] = '\n';
		    s.insert(last_wb+1, prefix);
		    current_pos = last_wb + 1 + psize;
		} else {
		    s.insert(last_wb+1, "\n" + prefix);
		    current_pos += 2 + psize;
		}

		line_pos = psize;
		last_wb = 0;
	    }

	    size = s.size();
	    continue;
	}

	if (std::strchr(word_boundries.c_str(), s[current_pos]))
	    last_wb = current_pos;

	++current_pos; ++line_pos;
    }
}
//####################################################################
/** 
 * Calls wrap without a prefix.
 *
 * @param s The string to wrap
 * @param width The target width
 * @author Peter Jones
**/
//####################################################################
template <typename T>
void wrap (T &s, typename T::size_type width) {wrap(s, width, T(""));}

} // end cxxtools namespace
#endif

