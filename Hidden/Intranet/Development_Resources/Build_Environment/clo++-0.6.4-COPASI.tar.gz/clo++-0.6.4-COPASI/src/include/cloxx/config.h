/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the definition of the cloxx::config class.
**/

#ifndef __cloxx_config_h__
#define __cloxx_config_h__

// includes for importing exporting
#include <xmlwrapp/node.h>
#include <libtpt/object.h>

// standard includes
#include <map>
#include <list>
#include <string>

namespace cloxx {

/**
 * The cloxx::config class is used to hold cloxx general configuration
 * information such as variables and code generation options.
**/
class config {
public:
    typedef std::map<std::string, std::string> variable_table;

    /// option order
    enum oporder {
	oporder_posix,	///< options and non-options can not be mixed
	oporder_gnu	///< options and non-options can be mixed
    };

    /// abbreviation style
    enum abbreviation {
	abbreviation_none,  ///< never accept abbreviated options
	abbreviation_gnu   ///< accept non-ambiguous option names
    };

    /// state for sub command usage
    enum command_state {
	command_optional,   ///< no command required
	command_mandatory  ///< must have one command
    };

    explicit config (const xml::node &n);
    config (void);
    config (const config &other);
    config& operator= (const config &other);
    void swap (config &other);
    ~config (void);

    void import_from_xml (const xml::node &n);
    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;

    void set_autohelp_state (bool state);
    void set_autohelp_id (const char *id);
    void set_autohelp_names (const std::list<std::string> &names);
    void set_variable (const char *name, const char *value);
    void set_true_words (const std::list<std::string> &true_words);
    void set_false_words (const std::list<std::string> &false_words);
    void set_oporder (oporder order);
    void set_abbreviation (abbreviation ab);
    void set_command_state (command_state state);
    void append_variables (const variable_table &vt);

    bool get_autohelp_state (void) const;
    const char* get_autohelp_id (void) const;
    const std::list<std::string>& get_autohelp_names (void) const;
    const char* get_autohelp_signature (void) const;
    const variable_table& get_variables (void) const;
    const std::list<std::string>& get_true_words (void) const;
    const std::list<std::string>& get_false_words (void) const;
    oporder get_oporder (void) const;
    abbreviation get_abbreviation (void) const;
    command_state get_command_state (void) const;
private:
    class pimpl; pimpl *pimpl_;
}; // end cloxx::config class

} // end cloxx namespace
#endif
