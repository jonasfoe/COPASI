/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the definition of the cloxx::group class.
**/

#ifndef __cloxx_group_h__
#define __cloxx_group_h__

// cloxx includes
#include <cloxx/option.h>

// includes for exporting
#include <xmlwrapp/node.h>
#include <libtpt/object.h>

// standard includes
#include <list>

namespace cloxx {

/**
 * The cloxx::group class contains information about option groups including
 * a list of options that are in the group.
**/
class group {
public:
    /// possible group types
    enum types {
	type_xor,   ///< options are mutualy exclusive
	type_or,    ///< only one of the options is necessary
	type_and    ///< all options must be used if one is used
    };

    explicit group (const xml::node &n);
    explicit group (const char *id);
    group (const group &other);
    group& operator= (const group &other);
    void swap (group &other);
    ~group (void);

    void export_to_xml (xml::node &n) const;
    void export_to_tpt (TPT::Object &o) const;
    
    void set_id (const char *id);
    void set_type (types t);
    void set_strict (bool strict);
    void set_mandatory (bool mandatory);

    void add_option (const option &o);
    void remove_option (const char *id);
    const std::list<option>& get_options (void) const;

    const char* get_id (void) const;
    types get_type (void) const;
    bool get_strict (void) const;
    bool get_mandatory (void) const;
private:
    class pimpl; pimpl *pimpl_;
}; // end cloxx::group

} // end cloxx namespace
#endif
