/*
 * Copyright (C) 2000-2003 Peter J Jones (pjones@pmade.org)
 * All Rights Reserved
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/** @file
 * This file contains the command line driver for the clo++ project.
**/

// include my command line parser
#include "options.h"

// include other cloxx stuff
#include <cloxx/app.h>
#include <cloxx/genfactory.h>
#include <cloxx/generator.h>

// include input and output headers
#include <xmlwrapp/xmlwrapp.h>
#include <libtpt/object.h>

// cxxtools includes
#include <cxxtools/cvs.h>

// standard includes
#include <iterator>
#include <iostream>
#include <algorithm>

namespace {
    const char rcsid[]	    = "$Id: main.cxx,v 1.17 2003/04/09 22:01:29 pjones Exp $";
    const char rcsname[]    = "$Name: REL-0_6_4 $";
}

// main entry point
int main (int argc, char *argv[]) {
    std::string version = cxxtools::cvstag2version(rcsname);
    if (version.empty()) version = rcsid;

    try {
	xml::init xmlinit;
	clo::parser clparser;
	cloxx::genfactory factory;

	clparser.parse(argc, argv);
	const clo::options &options = clparser.get_options();

	if (options.list_gen) {
	    const std::vector<const char*> &generators = factory.list_generators();
	    std::copy(generators.begin(), generators.end(), std::ostream_iterator<const char*>(std::cout, "\n"));
	    return 0;
	}

	const std::vector<std::string> &files = clparser.get_non_options();
	std::vector<std::string>::const_iterator file_it(files.begin()), file_end(files.end());

	if (files.empty()) {
	    std::cerr << argv[0] << ": missing XML input file\n";
	    return 1;
	}

	for (; file_it != file_end; ++file_it) {
	    xml::tree_parser xmlparser(file_it->c_str());
	    if (!xmlparser) {
		std::cerr << argv[0] << ": error parsing XML file " << *file_it << std::endl;
		return 1;
	    }

	    cloxx::app application(xmlparser.get_document().get_root_node());

	    cloxx::config config = application.get_config();
	    config.set_variable("version", version.c_str());
	    config.append_variables(options.variables);
	    application.set_config(config);

	    TPT::Object main_object(TPT::Object::type_hash);
	    application.export_to_tpt(main_object);

	    std::vector<clo::output_type_enum>::const_iterator 
		out_it(options.output_type.begin()),
		out_end(options.output_type.end());

	    for (; out_it != out_end; ++out_it) {
		cloxx::generator *gen(0);

		switch (*out_it) {
		    case clo::output_type_cpp:
		    case clo::output_type_cxx:
			gen = factory.get_generator("cxx");
			break;
		    case clo::output_type_xml:
			gen = factory.get_generator("xml");
			break;
		    case clo::output_type_tpt:
			gen = factory.get_generator("template");
			break;
		    case clo::output_type_man:
			gen = factory.get_generator("man");
			break;
		}

		gen->generate(application, main_object);
	    }
	}
    } catch (clo::autoexcept &e) {
	switch (e.get_autothrow_id()) {
	    case clo::autothrow_help:
		std::cout << "Usage: " << argv[0] << " -o generator [options] <xml file>\n";
		std::cout << e.what();
		return 0;
	    case clo::autothrow_version:
		std::cout << "This is clo++ version " << version << "\n";
		std::cout << "Please visit http://pmade.org/pjones/software/clo++/\n";
		return 0;
	}

	std::cerr << e.what() << "\n";
	return 1;
    } catch (clo::option_error &e) {
	std::cerr << argv[0] << ": " << e.what() << "\n";
	std::cerr << "[ " << e.get_help_comment() << " ]\n";
	return 1;
    } catch (std::exception &e) {
	std::cerr << argv[0] << ": " << e.what() << "\n";
	return 1;
    } catch ( ... ) {
	std::cerr << argv[0] << ": caught exception\n";
	return 1;
    }

    return 0;
}
