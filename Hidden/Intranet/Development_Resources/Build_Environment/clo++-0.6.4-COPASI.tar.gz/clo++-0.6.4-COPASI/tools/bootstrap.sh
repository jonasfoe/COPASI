#! /bin/sh

(cd src/library/templates; sh convert.sh)
perl configure.pl --developer
