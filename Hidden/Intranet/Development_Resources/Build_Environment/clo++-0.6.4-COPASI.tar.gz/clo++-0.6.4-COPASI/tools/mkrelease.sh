#! /bin/sh

PROJECT=clo++
VERSION_FILE=docs/VERSION

LIBTPT_URL="http://tazthecat.net/~isaac/libtpt/pub/libtpt-1.20.1a.tar.gz"
LIBTPT_FILE=`echo "$LIBTPT_URL" | perl -pe 's(^.*/)//;'`

XMLWRAPP_URL="http://pmade.org/pjones/software/xmlwrapp/download/xmlwrapp-0.4.2.tar.gz"
XMLWRAPP_FILE=`echo "$XMLWRAPP_URL" | perl -pe 's(^.*/)//;'`

STAGING_DIR="${HOME}/develop/release-staging"
CONTRIB_DIR=contrib
VERSION=`head -1 $VERSION_FILE | perl -pe 's/\s+.*$//'`
CVSTAG=`head -1 $VERSION_FILE  | perl -pe 's/^[\d.]+\s+([^\s]+).*$/$1/'`
DESTDIR="$PROJECT-$VERSION"
DEFAULT_FDP="${HOME}/develop/freebsd-doc-project"
DOCBOOK_XSL=$HOME/develop/xslt-tools/stylesheets/docbook2html.xsl
README_XSL=$HOME/develop/project-xslt/stylesheets/readme.xsl
W3M="w3m -cols 76 -dump"
XSLT="xsltproc"
URLGET="lftpget"

echo "===> Making $PROJECT release (Version == $VERSION) (CVSTAG == $CVSTAG)"

if [ ! -r $DOCBOOK_XSL ] ; then
    echo "missing $DOCBOOK_XSL"
    exit 1
fi

if [ ! -r $README_XSL ] ; then
    echo "missing $README_XSL"
    exit 1
fi

# checkout the correct tag/branch from CVS
cvs -q checkout -r $CVSTAG -d $DESTDIR $PROJECT

# remove the CVS directories
find $DESTDIR -name CVS -type d | xargs rm -rf

# download the necessary contrib packages
mkdir -p $STAGING_DIR

if test ! -r "${STAGING_DIR}/${LIBTPT_FILE}" ; then
    (cd $STAGING_DIR ; $URLGET $LIBTPT_URL || exit 1) || exit 1
fi

if test ! -r "${STAGING_DIR}/${XMLWRAPP_FILE}" ; then
    (cd $STAGING_DIR ; $URLGET $XMLWRAPP_URL || exit 1) || exit 1
fi

# put them in the contrib directory
(
    cd $DESTDIR/src

    mkdir $CONTRIB_DIR
    cd $CONTRIB_DIR

    tar xzvf ${STAGING_DIR}/${LIBTPT_FILE}
    tar xzvf ${STAGING_DIR}/${XMLWRAPP_FILE}
)

# build the templates
(cd $DESTDIR/src/library/templates; sh convert.sh)

# build the doxygen reference manual
#perl -i -pe "s/^\s*(PROJECT_NUMBER\s*=).*\$/\${1}$VERSION/" $DESTDIR/docs/doxygen/doxyfile
#(cd $DESTDIR/docs/doxygen; doxygen doxyfile)

# build the programming manual
if test "${FREEBSDDOC}x" = "x" -a -d $DEFAULT_FDP ; then
    export FREEBSDDOC=$DEFAULT_FDP
fi
(
    cd $DESTDIR/docs/manual
    make html
    $W3M one-html/manual.html > ../manual.txt
    make clean
)

# create the REAME, INSTALL and like files
TMPFILE=tmp.html
(
    cd $DESTDIR

    $XSLT $README_XSL docs/project/project.xml > $TMPFILE
    $W3M $TMPFILE > README

    $XSLT $DOCBOOK_XSL docs/manual/quickstart.xml > $TMPFILE
    $W3M $TMPFILE > INSTALL

    $XSLT $DOCBOOK_XSL docs/manual/credits.xml > $TMPFILE
    $W3M $TMPFILE > docs/CREDITS

    $XSLT $DOCBOOK_XSL docs/manual/todo.xml > $TMPFILE
    $W3M $TMPFILE > docs/TODO

    rm $TMPFILE
)

# create a tarball
tar czvf ${DESTDIR}.tar.gz $DESTDIR

# remove the directory that CVS created
rm -rf $DESTDIR
