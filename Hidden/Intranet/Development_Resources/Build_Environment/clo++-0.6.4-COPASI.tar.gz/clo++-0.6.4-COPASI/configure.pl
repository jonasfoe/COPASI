#! /usr/bin/perl
######################################################################
# Copyright (C) 2002-2003 Peter J Jones (pjones@pmade.org)
# All Rights Reserved
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 3. Neither the name of the Author nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
# OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
# USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
################################################################################
#
# configure.pl (bootstrap clo++)
# Peter J Jones (pjones@pmade.org)
#
################################################################################
#
# Includes
#
################################################################################
use strict;
use Getopt::Long;
use Cwd qw(cwd chdir);
################################################################################
#
# Constants
#
################################################################################
use constant DATE		=> 'Tue Jan 15 08:56:06 2002';
use constant ID			=> '$Id: configure.pl,v 1.10 2003/04/09 22:04:08 pjones Exp $';
################################################################################
#
# Global Variables
#
################################################################################
my $cwd = cwd();
my %clo;
my $dirsep = "/";

my $mkmf	= "${cwd}${dirsep}tools${dirsep}mkmf";
my $cxxflags	= "${cwd}${dirsep}tools${dirsep}cxxflags";
my $mkmf_flags  = "--cxxflags '$cxxflags' --quiet ";

my $libname	= "cloxx";
my $contrib_dir = "${cwd}${dirsep}src${dirsep}contrib";
my $install_spec= "${cwd}${dirsep}docs${dirsep}install.spec";

my $includes	= "--include '${cwd}${dirsep}src${dirsep}include' ";
my $libraries	= "--slinkwith '${cwd}${dirsep}src${dirsep}library,$libname' ";

my @extra_compile = (
    "${cwd}${dirsep}src${dirsep}library",
    "${cwd}${dirsep}src${dirsep}cmdline",
);
################################################################################
#
# Code Start
#
################################################################################
$|++;

if (not defined $ENV{'CXX'}) {
    print STDERR "**** your CXX environment variable is not set. clo++ needs this ****\n";
    print STDERR "**** variable to find your C++ compiler. Please set it to the   ****\n";
    print STDERR "**** path to your compiler and re-run configure.pl. Thanks.     ****\n";
    exit 1;
}

GetOptions(
    \%clo,
    'help',
    'developer',
    'xml2-config=s',
    'prefix=s',
    'bindir=s',
    'mandir=s',
) or usage();
$clo{'help'} && usage();

sub usage {
    print "Usage: $0 [options]\n", <<EOT;
  --developer         Turn on developer mode

  --prefix path       Set the install prefix to path [/usr/local]
  --bindir path       Set the install bin dir to path [PREFIX/bin]
  --mandir path       Set the install man dir to path [PREFIX/man]

  --xml2-config path  Use the xml2-config script given by path.
EOT
    exit;
}

$clo{'prefix'}	    ||= "/usr/local";
$clo{'bindir'}	    ||= "$clo{'prefix'}/bin";
$clo{'mandir'}	    ||= "$clo{'prefix'}/man";
    
if ($clo{'developer'}) {
    $mkmf_flags .= "--developer ";
}

find_contrib_libs();

print "Generating clo++ Makefiles ";
generate_toplevel_makefile();
generate_library_makefile();
generate_cmdline_makefile();
print "\n";
print "+---------------------------------------------------------------+\n";
print "|  Join the announcement mailing list for release annoucements  |\n";
print "|        http://pmade.org/mailman/listinfo/cloxx-announce       |\n";
print "|                                                               |\n";
print "|        Join the users mailing list for help with clo++        |\n";
print "|         http://pmade.org/mailman/listinfo/cloxx-users         |\n";
print "+---------------------------------------------------------------+\n";
################################################################################
sub find_contrib_libs {
    my @files = glob("$contrib_dir${dirsep}*");
    my ($xmlwrapp, $libtpt);

    foreach my $file (@files) {
	if ($file =~ /xmlwrapp/) {
	    $xmlwrapp = $file;
	} elsif ($file =~ /libtpt/) {
	    $libtpt = $file;
	}
    }

    if (not defined $xmlwrapp) {
	print STDERR "$0: can't locate xmlwrapp, your package is incomplete\n";
	exit 1;
    }

    my $xmlextra = ''; if ($clo{'xml2-config'}) {$xmlextra = "--xml2-config '$clo{'xml2-config'}'";}
    system("cd $xmlwrapp ; $^X configure.pl --contrib --disable-xslt $xmlextra") and exit 1;

    my $xmlwrapp_config = "$xmlwrapp${dirsep}xmlwrapp-config";
    if (not -e $xmlwrapp_config) {
	print STDERR "$0: failed to configure xmlwrapp\n";
	exit 1;
    }

    my ($xmlwrapp_includes, $xmlwrapp_libraries);
    chomp($xmlwrapp_includes = `$xmlwrapp_config --cxxflags`);
    chomp($xmlwrapp_libraries = `$xmlwrapp_config --libs`);

    if (not defined $libtpt) {
	print STDERR "$0: can't locate libtpt, your package is incomplete\n";
	exit 1;
    }

    print "Configuring libtpt ...\n";
    system("cd $libtpt ; $^X configure.pl --bundle") and exit 1;

    $ENV{'CXXFLAGS'} .= " $xmlwrapp_includes";
    $ENV{'LDFLAGS'}  .= " $xmlwrapp_libraries";
    unshift(@extra_compile, $xmlwrapp);

    $includes .= "--include '$libtpt${dirsep}inc' ";
    $libraries .= "--slinkwith '$libtpt${dirsep}src${dirsep}lib,tpt' ";
    unshift(@extra_compile, "$libtpt${dirsep}src${dirsep}lib");
}
################################################################################
sub generate_toplevel_makefile {
    unless (open(SPEC, ">$install_spec")) {
	print STDERR "\n$0: can't open $install_spec: $!\n";
	exit 1;
    }

    print SPEC "bindir=$clo{'bindir'}\n";
    print SPEC "mandir=$clo{'mandir'}\n";
    print SPEC "binary src${dirsep}cmdline${dirsep}clo++\n";
    print SPEC "man 1 src${dirsep}cmdline${dirsep}clo++.1\n";
    close SPEC;

    system("$^X $mkmf $mkmf_flags --with-test '$cwd${dirsep}tests' --install $install_spec --wrapper @extra_compile");
    print ".";
}
################################################################################
sub generate_library_makefile {
    if (not chdir("$cwd${dirsep}src${dirsep}library")) {
	print STDERR "\n$0: can't chdir to src${dirsep}library: $!\n";
	exit 1;
    }

    system("$^X $mkmf $mkmf_flags $includes --static-lib $libname *.cxx");
    print ".";
    chdir $cwd;
}
#################################################################################
sub generate_cmdline_makefile {
    if (not chdir("$cwd${dirsep}src${dirsep}cmdline")) {
	print STDERR "\n$0: can't chdir to src${dirsep}cmdline: $!\n";
	exit 1;
    }

    system("$^X $mkmf $mkmf_flags $includes $libraries --one-exec clo++ *.cxx");
    print ".";
    chdir $cwd;
}
